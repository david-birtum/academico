from odoo import fields, models, api
from dateutil.relativedelta import relativedelta


class CommissionMembership(models.Model):
    _name = 'commission.membership'
    _description = 'Commission Membership'
    _rec_name = 'number_membership_trade'

    workday_id_dm = fields.Char()
    division = fields.Char()
    segment = fields.Char()
    employee_number_manager = fields.Char()
    workday_id = fields.Char()
    name_rm_gptm = fields.Char()
    number_membership_trade = fields.Char()
    trade_name = fields.Char()
    trade_rfc = fields.Char()
    mcc = fields.Char()
    family = fields.Char()
    date_install = fields.Datetime()
    state = fields.Selection(
        [
            ('draft', 'Draft'),
            ('computed', 'Computed'),
            ('done', 'Done'),
        ], default='draft'
    )
    status = fields.Selection(
        [
            ('active', 'Con expediente'),
            ('inactive', 'Sin expediente'),
        ], default='inactive'
    )
    activation_date = fields.Datetime()
    current_month = fields.Integer(
        compute='_compute_current_month',
        store=True
    )
    file_uploaded_id = fields.Many2one(
        'commission.file.loaded',
        ondelete='cascade'
    )
    line_ids = fields.One2many(
        'commission.membership.line',
        'membership_id',
        string='Lines'
    )
    dia_date = fields.Datetime("Mes de DIA")
    deposit_date = fields.Datetime("Mes de Depósito")
    counted_date = fields.Datetime("Mes de Conteo")

    @api.depends('line_ids')
    def _compute_current_month(self):
        """Compute the current month of the membership."""
        # today = fields.Datetime.today()
        for membership in self:
            # twelve_months_in_future = membership.activation_date\
            #                           + relativedelta(months=12)
            membership.current_month = len(membership.line_ids)
            if membership.current_month >= 12:
                    # or twelve_months_in_future > today:
                membership.status = 'inactive'
                membership.state = 'done'


class CommissionMembershipLine(models.Model):
    _name = 'commission.membership.line'
    _description = 'Commission Membership Line'
    _inherit = 'commission.currency.abstract'

    membership_id = fields.Many2one(
        'commission.membership'
    )
    date = fields.Datetime()
    tx_month = fields.Integer()
    total_bills = fields.Float(digits=(16, 2))
    rentability = fields.Float(digits=(16, 2))
    credit_discount = fields.Float(digits=(16, 4))
    debit_discount = fields.Float(digits=(16, 4))
    credit_exchange_rate = fields.Float(digits=(16, 4))
    debit_exchange_rate = fields.Float(digits=(16, 4))
    file_computed_id = fields.Many2one(
        'commission.file.loaded.computed'
    )
    file_uploaded_id = fields.Many2one(
        'commission.file.loaded',
        ondelete='cascade'
    )
    state = fields.Selection(
        [
            ('draft', 'Draft'),
            ('computed', 'Computed'),
            ('pending', 'Pending Files'),
            ('done', 'Payed'),
        ], default='draft'
    )
