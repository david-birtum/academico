from odoo import fields, models, api


class CommissionFileLoadedComputed(models.Model):
    _name = 'commission.file.loaded.computed'
    _description = 'Commission File Loaded Computed'

    workday_id_dm = fields.Char()
    division = fields.Char()
    segment = fields.Char()
    employee_number_manager = fields.Char()
    workday_id = fields.Char()
    name_rm_gptm = fields.Char()
    number_membership_trade = fields.Char()
    trade_name = fields.Char()
    trade_rfc = fields.Char()
    mcc = fields.Char()
    family = fields.Char()
    credit_discount = fields.Float(digits=(16, 4))
    debit_discount = fields.Float(digits=(16, 4))
    credit_exchange_rate = fields.Float(digits=(16, 4))
    debit_exchange_rate = fields.Float(digits=(16, 4))
    date_install = fields.Datetime()
    tx_month = fields.Integer()
    total_bills = fields.Float()
    rentability = fields.Float()
    dia_date = fields.Datetime()
    deposit_date = fields.Datetime()
    counted_date = fields.Datetime()
    file_uploaded_id = fields.Many2one(
        'commission.file.loaded',
        ondelete='cascade'
    )


    def unlink(self):
        """Unlink   a transaction"""
        for computed in self:
            computed.run_rollback()
            computed.unlink_memberships_and_lines()
        return super(CommissionFileLoadedComputed, self).unlink()

    def unlink_memberships_and_lines(self):
        '''
        Cuando se borra un archivo de mes, se buscan las líneas de Afiliación que se crearon
        asociadas a ese archivo, si la Afiliación aún tiene líneas solo se borra la línea
        si es la única línea se borra también la Afiliación
        '''
        lines = self.env['commission.membership.line'].search(
                [
                    ('file_computed_id', '=', self.id)
                ]
            )
        membership_id = lines.mapped('membership_id')
        if len(membership_id.line_ids) == len(lines):
            membership_id.unlink()
        lines.unlink()

    @api.model
    def create_line(self, computed, membership_id, default_vals=None):
        """
        It creates a new line in the commission.membership.line table, using the
        values from the computed table

        :param computed: the computed object
        :param membership_id: the membership record
        :param default_vals: a dictionary of values to be added to the values
        dictionary
        :return: A new record in the commission.membership.line table.
        """
        default_vals = dict(default_vals or {})
        membership_line = self.env['commission.membership.line']
        values = {
            'date': computed.deposit_date,
            'tx_month': computed.tx_month,
            'total_bills': computed.total_bills,
            'rentability': computed.rentability,
            'credit_discount': (computed.credit_discount / 100) or 0,
            'debit_discount': (computed.debit_discount / 100) or 0,
            'credit_exchange_rate': (computed.credit_exchange_rate / 100) or 0,
            'debit_exchange_rate': (computed.debit_exchange_rate / 100) or 0,
            'membership_id': membership_id.id,
            'file_computed_id': computed.id,
            'file_uploaded_id': membership_id.file_uploaded_id.id,
        }
        values.update(default_vals)
        return membership_line.create(values)

    def execute_month_calculation(self):
        """
        It creates a new record in the commission.membership table if the record
        doesn't exist, and then creates a new record in the
        commission.membership.line table
        :return: The return value is a dictionary.
        """
        # sourcery skip: dict-assign-update-to-union
        """Execute the month calculation"""
        membership = self.env['commission.membership']
        for computed in self:
            state = {}
            if computed.file_uploaded_id.definitive:
                if self.env['commission.files.status'].is_inactive(
                    computed.number_membership_trade
                ):
                    state = {'state': 'pending'}
                else:
                    state = {'state': 'computed'}
            membership_id = membership.search(
                [
                    (
                        'number_membership_trade',
                        '=',
                        computed.number_membership_trade
                    ),
                    ('workday_id', '=', computed.workday_id)
                ], limit=1
            )
            if membership_id:
                membership_id.write({'deposit_date': computed.deposit_date})
                already_line = membership_id.line_ids.filtered(
                    lambda x: x.file_computed_id.id == computed.id
                )
                if membership_id.state == 'draft':
                    membership_id.state = 'computed'
                if already_line:
                    vals = {
                        'date': computed.deposit_date
                    }
                    if state:
                        vals.update(state)
                    already_line.write(vals)
                else:
                    self.create_line(
                        computed,
                        membership_id,
                        default_vals=state
                    )
            else:
                membership_vals = {
                    'workday_id_dm': computed.workday_id_dm,
                    'division': computed.division,
                    'segment': computed.segment,
                    'employee_number_manager':
                        computed.employee_number_manager,
                    'workday_id': computed.workday_id,
                    'name_rm_gptm': computed.name_rm_gptm,
                    'number_membership_trade':
                        computed.number_membership_trade,
                    'trade_name': computed.trade_name,
                    'trade_rfc': computed.trade_rfc,
                    'mcc': computed.mcc,
                    'family': computed.family,
                    'date_install': computed.date_install,
                    'dia_date': computed.dia_date,
                    'deposit_date': computed.deposit_date,
                    'counted_date': computed.counted_date,
                    'file_uploaded_id': computed.file_uploaded_id.id,
                }
                membership_vals.update(state)
                membership_id = membership.create(
                    membership_vals
                )
                self.create_line(
                    computed,
                    membership_id,
                    default_vals=state
                )
                # self.env['res.partner'].add_rm_to_dm(
                #     computed.workday_id_dm,
                #     computed.workday_id
                # )
        return True

    def run_rollback(self):
        '''Sets memberships and commission lines to a previous state if the file is deleted.
        '''
        membership_to_clear=self.env['membership.rollback'].search([])
        for membership in membership_to_clear:
            membership.name.status = 'inactive'
        membership_to_clear.unlink()

        lines_to_clear=self.env['commission.rollback'].search([])
        for line in lines_to_clear:
            line.name.membership_file_info = False
        lines_to_clear.unlink()
