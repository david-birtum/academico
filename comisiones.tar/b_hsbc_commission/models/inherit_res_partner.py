# Copyright 2017 ForgeFlow S.L.
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl)
from odoo import fields, models, api, _
from odoo.exceptions import ValidationError


class ResPartner(models.Model):
    _inherit = 'res.partner'

    category_select = fields.Selection(
        [
            ('dm', 'DM'),
            ('rm', 'RM'),
            ('cco', 'CCO'),
            ('emsr', 'EMSR'),
            ('em', 'EM'),
            ('manager', 'Manager'),
        ],
        default='dm'
    )
    position_id = fields.Many2one(
        'partner.commission.position',
    )
    workday_id = fields.Char()
    number = fields.Char()
    dm_id = fields.Many2one(
        'res.partner',
        string='Related DM',
        index=True
    )
    rm_ids = fields.One2many(
        'res.partner',
        'dm_id',
        string='RM',
    )
    is_hsbc_employee = fields.Boolean(
        string="Is Global Payments Employee"
    )
    division = fields.Char()

    def unlink(self):
        for partner in self:
            if partner.user_ids:
                partner.user_ids.unlink()
        return super(ResPartner, self).unlink()

    @api.model
    def add_rm_to_dm(self, workday_id_dm, workday_id):
        dm = self.env['res.partner'].search(
            [
                ('workday_id', '=', workday_id_dm)
            ], limit=1
        )
        # if not dm:
        #     raise ValidationError(
        #         _(f'DM not found {workday_id_dm}')
        #     )
        rm = self.env['res.partner'].search(
            [
                ('workday_id', '=', workday_id)
            ], limit=1
        )
        # if not rm:
        #     raise ValidationError(
        #         _(f'RM not found {workday_id}')
        #     )
        rm.dm_id = dm.id
        return True
