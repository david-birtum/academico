from odoo import fields, models


class CommissionFileLoadedEmployees(models.Model):
    _name = 'commission.file.loaded.employees'
    _description = 'Commission File Loaded Employees'

    category_select = fields.Selection(
        [
            ('dm', 'DM'),
            ('rm', 'RM'),
            ('cco', 'CCO'),
            ('emsr', 'EMSR'),
            ('em', 'EM'),
            ('manager', 'Manager'),
        ],
        default='rm'
    )
    position_id = fields.Many2one(
        'partner.commission.position',
    )
    name = fields.Char()
    workday_id = fields.Char()
    division = fields.Char()
    workday_superior = fields.Char()
    email = fields.Char()
    file_uploaded_id = fields.Many2one(
        'commission.file.loaded'
    )

    def assign_hierarchy(self):
        partner = self.env['res.partner']
        for employee in self:
            superior = partner.search(
                [
                    ('workday_id', '=', employee.workday_superior)
                ], limit=1
            )
            workday = partner.search(
                [
                    ('workday_id', '=', employee.workday_id)
                ], limit=1
            )
            workday.dm_id = superior

    def execute_employee_file(self):
        partner = self.env['res.partner']
        for employee in self:
            if employee.workday_id != '[Vacante]':
                already_partner = partner.self.with_context(
                    active_test=False
                ).search(
                    [
                        ('workday_id', '=', employee.workday_id),
                    ], limit=1
                )
                if already_partner:
                    already_partner.write({
                        'active': True,
                        'category_select': employee.category_select,
                        'position_id': employee.position_id.id,
                        'name': employee.name,
                        'division': employee.division,
                        'email': employee.email,
                        'is_hsbc_employee': True,
                        'workday_id': employee.workday_id,
                    })
                    if already_partner.user_ids:
                        already_partner.user_ids.write({
                            'active': True,
                        })
                    if employee.email:
                        wizard_id = self.env['portal.wizard'].create(
                            {
                                'user_ids': [(0, 0, {
                                    'partner_id': already_partner.id,
                                    'email': employee.email,
                                    'in_portal': True,
                                    'user_id': already_partner.user_ids and
                                       already_partner.user_ids.ids[0] or False,
                                })]
                            }
                        )
                        wizard_id.action_apply()
                else:
                    partner_id = partner.create({
                        'active': True,
                        'category_select': employee.category_select,
                        'position_id': employee.position_id.id,
                        'name': employee.name,
                        'division': employee.division,
                        'email': employee.email,
                        'is_hsbc_employee': True,
                        'workday_id': employee.workday_id,
                    })
                    if employee.email:
                        wizard_id = self.env['portal.wizard'].create(
                            {
                                'user_ids': [(0, 0, {
                                    'partner_id': partner_id.id,
                                    'email': employee.email,
                                    'in_portal': True,
                                    'user_id': False,
                                })]
                            }
                        )
                        wizard_id.action_apply()
