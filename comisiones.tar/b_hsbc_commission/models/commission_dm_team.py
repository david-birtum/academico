from odoo import fields, models


class CommissionDMTeam(models.Model):
    _name = 'commission.dm.team'
    _description = 'Commission DM Team'
    _rec_name = 'workday_id'

    name = fields.Char()
    workday_id = fields.Char()
    current_members = fields.Integer()
    goal_members = fields.Integer()
    file_uploaded_id = fields.Many2one(
        'commission.file.loaded',
        ondelete='cascade'
    )
    date = fields.Datetime(
        default=lambda self: fields.Datetime.now(),
    )
