from odoo import fields, models
import logging
_logger = logging.getLogger(__name__)


class CommissionReporting(models.Model):
    _name = 'commission.reporting'
    _description = 'Commission Reporting'
    _inherit = 'commission.currency.abstract'

    partner_dm_id = fields.Many2one(
        'res.partner'
    )
    partner_dm_workday_id = fields.Char(
        related='partner_dm_id.workday_id',
        store=True
    )
    name = fields.Char(
        related='partner_dm_id.name'
    )
    division = fields.Char()
    segment = fields.Char()
    partner_rm_id = fields.Many2one(
        'res.partner'
    )
    partner_rm_workday_id = fields.Char(
        related='partner_rm_id.workday_id',
        store=True
    )
    name_rm_gptm = fields.Char(
        related='partner_rm_id.name'
    )
    membership = fields.Char()
    trade_name = fields.Char()
    rfc = fields.Char()
    family = fields.Char()
    install_date = fields.Datetime()
    product = fields.Char()
    harvest = fields.Char()
    deposit_month = fields.Char()
    volume = fields.Float()
    transaction = fields.Integer()
    rentability = fields.Float(digits=(16, 2))
    percentage = fields.Float()
    commission = fields.Float(digits=(16, 2))
    file_uploaded_id = fields.Many2one(
        'commission.file.loaded',
        ondelete='cascade'
    )
