from odoo import fields, models

import logging
_logger = logging.getLogger(__name__)


class CommissionAccountDM(models.Model):
    _name = 'commission.account.dm'
    _description = 'Commission Account DM'
    _inherit = 'commission.currency.abstract'

    date = fields.Datetime()
    deposit_month = fields.Char()
    harvest = fields.Char()
    partner_id = fields.Many2one(
        'res.partner'
    )
    workday_id = fields.Char(
        related='partner_id.workday_id',
    )
    name = fields.Char(
        related='partner_id.name',
    )
    number_of_rm = fields.Integer()
    month_goals = fields.Integer()
    rfc = fields.Char()
    file_uploaded_id = fields.Many2one(
        'commission.file.loaded',
        ondelete='cascade'
    )
    commission_id = fields.Many2one(
        'commission.partner.membership'
    )
    # TODO: division, Para que se utiliza este campo y de donde sale
    division = fields.Char()
    percentage = fields.Float()
    commission = fields.Float(digits=(16, 2))

    def _get_report_base_filename(self):
        self.ensure_one()
        return 'Estado de Cuenta DM'

    def _get_dm_installed_membership_lines(self, objetc_id):
        '''
        Get installed memberships for DM pdf report 
        '''
        if objetc_id._name == 'commission.partner.membership':
            commission_id = objetc_id
        elif objetc_id._name == 'commission.account.dm':
            commission_id = objetc_id.commission_id
        else:
            return
        membership_id =self.env['commission.partner.membership'].search([('partner_id', '=', commission_id.partner_id.id), ('state', '=', 'pending'),('file_uploaded_id', '=', commission_id.file_uploaded_id.id )], limit=1)
        if membership_id:
            pending_lines = membership_id.line_ids.filtered(lambda x: not x.origin_commission)
            return commission_id.line_ids.filtered(lambda x: not x.origin_commission) | pending_lines
        return commission_id.line_ids.filtered(lambda x: not x.origin_commission)

    def _get_dm_membership_without_documents_lines(self, objetc_id):
        '''
        Get memberships without documents () 
        '''
        if objetc_id._name == 'commission.partner.membership':
            commission_id = objetc_id
        elif objetc_id._name == 'commission.account.dm':
            commission_id = objetc_id.commission_id
        else:
            return
        membership_id =self.env['commission.partner.membership'].search([('partner_id', '=', commission_id.partner_id.id), ('state', '=', 'pending'),('file_uploaded_id', '=', commission_id.file_uploaded_id.id )], limit=1)
        return membership_id.line_ids
