from odoo import fields, models


class CommissionFileLoadedMaximumRates(models.Model):
    '''
    When a Excel file whit Memberships that hace maximum rate is loaded (before being processed), 
    the records are stored in this model.
    '''
    _name = 'commission.file.loaded.maximum.rates'
    _description = 'Commission File Loaded whit Maximum Rates'

    name = fields.Char(
        string='Membership',
        help='Membership with maximum rate',
    )
    file_uploaded_id = fields.Many2one(
        'commission.file.loaded',
        string='File id',
        help='Excel file that originates the record',
    )
