from odoo import fields, models


class CommissionFileLoadedDMTeam(models.Model):
    _name = 'commission.file.loaded.dm.team'
    _description = 'Commission File Loaded DM Team'

    workday_id = fields.Char()
    name = fields.Char()
    current_members = fields.Integer()
    goal_members = fields.Integer()
    file_uploaded_id = fields.Many2one(
        'commission.file.loaded',
        ondelete='cascade'
    )
    date = fields.Datetime(
        default=lambda self: fields.Datetime.now(),
    )
