from odoo import http, _, fields
from odoo.http import request
from odoo.tools.misc import xlsxwriter

import io
from odoo.addons.portal.controllers.portal import CustomerPortal, \
    pager as portal_pager


class CustomerPortal(CustomerPortal):

    def _prepare_home_portal_values(self, counters):
        values = super()._prepare_home_portal_values(counters)
        if 'statements_count' in counters:
            statements_count = 0
            if request.env.user.category_select == 'dm':
                statements_count = request.env[
                    'commission.account.dm'
                ].search_count(
                    [
                        ('partner_id', '=', request.env.user.partner_id.id),
                    ]
                ) if request.env['commission.account.dm'].check_access_rights(
                    'read',
                    raise_exception=False
                ) else 0
            elif request.env.user.category_select == 'rm':
                statements_count = request.env[
                    'commission.account.rm'
                ].search_count(
                    [
                        ('partner_id', '=', request.env.user.partner_id.id),
                    ]
                ) if request.env['commission.account.rm'].check_access_rights(
                    'read',
                    raise_exception=False
                ) else 0
            elif request.env.user.category_select in ['em', 'manager']:
                statements_count = request.env[
                    'commission.account.enterprise'
                ].search_count(
                    [
                        ('partner_id', '=', request.env.user.partner_id.id),
                    ]
                ) if request.env[
                    'commission.account.enterprise'
                ].check_access_rights(
                    'read',
                    raise_exception=False
                ) else 0
            values['statements_count'] = statements_count
        return values

    @http.route(['/my/statements', '/my/statements/page/<int:page>'],
                type='http', auth="user", website=True)
    def portal_my_statements(self, page=1, date_begin=None, date_end=None,
                             sortby=None, **kw):
        values = self._prepare_portal_layout_values()
        Statement_dm = request.env['commission.account.dm']
        Statement_rm = request.env['commission.account.rm']
        Statement_enterprise = request.env['commission.account.enterprise']
        domain = [('partner_id', '=', request.env.user.partner_id.id)]
        rm_statemens = request.env['commission.account.rm']

        searchbar_sortings = {
            'date': {'label': _('Newest'), 'order': 'create_date desc'},
            'name': {'label': _('Name'), 'order': 'name'},
        }
        if not sortby:
            sortby = 'date'
        order = searchbar_sortings[sortby]['order']

        if date_begin and date_end:
            domain += [
                ('create_date', '>', date_begin),
                ('create_date', '<=', date_end)
            ]

        # statements count
        if request.env.user.category_select == 'rm':
            statement_count = Statement_rm.search_count(domain)
        elif request.env.user.category_select == 'dm':
            statement_count = Statement_dm.search_count(domain)
        elif request.env.user.category_select in ['em', 'manager']:
            statement_count = Statement_enterprise.search_count(domain)
        else:
            statement_count = 0
        # pager
        pager = portal_pager(
            url="/my/statements",
            url_args={'date_begin': date_begin, 'date_end': date_end,
                      'sortby': sortby},
            total=statement_count,
            page=page,
            step=self._items_per_page
        )
        model_statements = 'commission.account.rm'
        # content according to pager and archive selected
        if request.env.user.category_select == 'rm':
            statments = Statement_rm.sudo().search(domain, order=order,
                                                   limit=self._items_per_page,
                                                   offset=pager['offset'])
        elif request.env.user.category_select == 'dm':
            statments = Statement_dm.sudo().search(domain, order=order,
                                                   limit=self._items_per_page,
                                                   offset=pager['offset'])
            model_statements = 'commission.account.dm'
        elif request.env.user.category_select in ['em', 'manager']:
            statments = Statement_enterprise.sudo().search(domain, order=order,
                                                           limit=self._items_per_page,
                                                           offset=pager[
                                                               'offset'])
            model_statements = 'commission.account.enterprise'
        else:
            statments = Statement_rm.sudo()
        if request.env.user.category_select == 'dm':
            rm_statemens = Statement_rm.sudo().search(
                [('partner_dm_id', '=', request.env.user.partner_id.id)],
                order=order,
                limit=self._items_per_page,
                offset=pager['offset']
            )
        values.update({
            'date': date_begin,
            'date_end': date_end,
            'statements': statments.sudo(),
            'page_name': 'statement',
            'model_statement': model_statements,
            'default_url': '/my/statements',
            'pager': pager,
            'searchbar_sortings': searchbar_sortings,
            'rm_statemens': rm_statemens.sudo(),
            'rm_model_statement': 'commission.account.rm',
            'sortby': sortby
        })
        return request.render("b_hsbc_commission.portal_my_statements", values)

    @http.route(['/my/statements/<int:statement_id>'],
                type='http', auth="public", website=True)
    def portal_my_statements_print(self, statement_id, access_token=None,
                                   source=False,
                                   report_type=None, download=False,
                                   message=False,
                                   model_statement='commission.account.rm',
                                   **kw):
        #Se agregó un report_type llamado pdfrm solo para identificar que se quiere imprimir un documento
        #de un miembro del equipo (usuario RM), ya que se genera un error si siempre se pasaba account_dm_previo
        if report_type in ('html', 'pdf', 'text','pdfrm'):
            statement_sudo = self._document_check_access(
                model_statement, statement_id, access_token
            )
            report_name = 'b_hsbc_commission.account_dm_previo'
            if request.env.user.category_select == 'rm':
                report_name = 'b_hsbc_commission.account_rm_previo'
            elif request.env.user.category_select == 'dm' and report_type=='pdf':
                report_name = 'b_hsbc_commission.account_dm_previo'
            elif request.env.user.category_select == 'dm' and report_type=='pdfrm':
                report_name = 'b_hsbc_commission.account_rm_previo'
            elif request.env.user.category_select in ['em', 'manager']:
                report_name = 'b_hsbc_commission.account_ent_previo'
            return self._show_report(
                model=statement_sudo,
                report_type= 'pdf' if report_type=='pdfrm' else report_type,
                report_ref=report_name,
                download=download
            )
        elif report_type == 'xls':
            statement_sudo = request.env[
                model_statement
            ].sudo().browse(statement_id)
            output = io.BytesIO()
            workbook = xlsxwriter.Workbook(output, {'in_memory': True})
            if model_statement == 'commission.account.rm':
                report_name = "Reporte_RM.xlsx;"
                # commission_installed_lines = statement_sudo.commission_id. \
                #                                  line_ids.filtered(
                #     lambda x: not x.origin_commission
                # ) | statement_sudo.commission_pending_id.line_ids
                commission_installed_lines = statement_sudo.commission_id.line_ids.filtered(
                    lambda x: not x.origin_commission) | statement_sudo.commission_pending_id.line_ids.filtered(lambda x: not x.origin_commission)

                commission_payed = statement_sudo.commission_id.line_ids. \
                    filtered(
                    lambda x: x.commission_status in ['success', 'failure']
                              and not x.origin_commission
                )
                commission_lines_payed_pending = statement_sudo. \
                    commission_id.line_ids.filtered(
                    lambda x: x.commission_status in ['success', 'failure']
                              and x.origin_commission
                )
                # commission_lines_pending = statement_sudo. \
                #     commission_pending_id.line_ids.filtered(
                #     lambda x: x.commission_status in ['pending']
                # )
                commission_lines_pending = statement_sudo. \
                    commission_pending_id.line_ids
                self.report_firts_page_rm(workbook, statement_sudo)
            elif model_statement == 'commission.account.enterprise':
                report_name = "Reporte_Enterprise.xlsx;"
                commission_installed_lines = statement_sudo.commission_id.line_ids.filtered(
                    lambda x: not x.origin_commission) | statement_sudo.commission_pending_id.line_ids.filtered(lambda x: not x.origin_commission)
                commission_payed = statement_sudo.commission_id.line_ids.\
                    filtered(
                    lambda x: x.commission_status in ['success', 'failure']
                              and not x.origin_commission
                )
                commission_lines_payed_pending = statement_sudo. \
                    commission_id.line_ids.filtered(
                    lambda x: x.commission_status in ['success', 'failure']
                              and x.origin_commission
                )
                commission_lines_pending = statement_sudo._get_enterprise_membership_without_documents_lines(statement_sudo)
                self.report_firts_page_enterprise(workbook, statement_sudo)
            else:
                report_name = "Reporte_DM.xlsx;"
                commission_installed_lines = statement_sudo._get_dm_installed_membership_lines(statement_sudo)
                commission_payed = statement_sudo.commission_id.line_ids. \
                    filtered(
                    lambda x: x.commission_status in ['success', 'failure']
                              and not x.origin_commission)
                commission_lines_payed_pending = statement_sudo. \
                    commission_id.line_ids.filtered(
                    lambda x: x.commission_status in ['success', 'failure']
                              and x.origin_commission
                )
                commission_lines_pending = statement_sudo._get_dm_membership_without_documents_lines(statement_sudo)
                self.report_firts_page_dm(workbook, statement_sudo)

            self.instalations_membership(
                workbook,
                statement_sudo,
                commission_installed_lines
            )
            self.payed_membership(
                'Pagadas',
                workbook,
                statement_sudo,
                commission_payed
            )
            self.payed_membership(
                'Pagadas anteriores',
                workbook,
                statement_sudo,
                commission_lines_payed_pending
            )
            self.payed_membership(
                'No pagadas',
                workbook,
                statement_sudo,
                commission_lines_pending
            )
            workbook.close()
            xlsx_data = output.getvalue()
            if xlsx_data:
                content_base64 = xlsx_data
                pdfhttpheaders = [
                    ('Content-Type', 'application/vnd.ms-excel'),
                    ('Content-Length', len(content_base64)),
                    ('Content-Disposition',
                     'attachment; filename=' + report_name)
                ]
                return request.make_response(content_base64,
                                             headers=pdfhttpheaders)
        return request.redirect('/my/statements')

    def report_firts_page_rm(self, workbook, statement_sudo):
        worksheet_afi = workbook.add_worksheet(
            statement_sudo.partner_id.name
        )
        style_highlight = workbook.add_format(
            {
                'bold': True,
                'pattern': 1,
                'bg_color': '#E0E0E0',
                'align': 'center'
            }
        )
        style_normal = workbook.add_format({'align': 'center'})
        # Nombre
        worksheet_afi.write(0, 0, 'Nombre', style_highlight)
        worksheet_afi.set_column(0, 0, 30)
        worksheet_afi.write(0, 1, statement_sudo.name, style_normal)
        worksheet_afi.set_column(0, 1, 30)
        #     Division
        worksheet_afi.write(1, 0, 'DIVISION', style_highlight)
        worksheet_afi.set_column(1, 0, 30)
        worksheet_afi.write(1, 1, statement_sudo.division, style_normal)
        worksheet_afi.set_column(1, 1, 30)
        #     Division
        worksheet_afi.write(2, 0, 'WORKDAY_ID_DM', style_highlight)
        worksheet_afi.set_column(2, 0, 30)
        worksheet_afi.write(2, 1, statement_sudo.partner_dm_workday_id,
                            style_normal)
        worksheet_afi.set_column(2, 1, 30)

        worksheet_afi.write(3, 0, 'WORKDAY_ID', style_highlight)
        worksheet_afi.set_column(3, 0, 30)
        worksheet_afi.write(3, 1, statement_sudo.workday_id,
                            style_normal)
        worksheet_afi.set_column(3, 1, 30)

        # Cosecha
        worksheet_afi.write(0, 3, 'Cosecha', style_highlight)
        worksheet_afi.set_column(0, 3, 30)
        worksheet_afi.write(0, 4, statement_sudo.harvest, style_normal)
        worksheet_afi.set_column(0, 4, 30)
        # Division
        worksheet_afi.write(1, 3, 'Mes Depósito:', style_highlight)
        worksheet_afi.set_column(1, 3, 30)
        worksheet_afi.write(1, 4, statement_sudo.deposit_month, style_normal)
        worksheet_afi.set_column(1, 4, 30)
        # Fecha descarga
        worksheet_afi.write(2, 3, 'Fecha de descarga', style_highlight)
        worksheet_afi.set_column(2, 3, 30)
        worksheet_afi.write(2, 4, statement_sudo.deposit_date.strftime("%d/%m/%Y") or '', style_normal)
        worksheet_afi.set_column(2, 4, 30)

    def report_firts_page_enterprise(self, workbook, statement_sudo):
        worksheet_afi = workbook.add_worksheet(
            statement_sudo.partner_id.name
        )
        style_highlight = workbook.add_format(
            {
                'bold': True,
                'pattern': 1,
                'bg_color': '#E0E0E0',
                'align': 'center'
            }
        )
        style_normal = workbook.add_format({'align': 'center'})
        # Nombre
        worksheet_afi.write(0, 0, 'Nombre', style_highlight)
        worksheet_afi.set_column(0, 0, 30)
        worksheet_afi.write(0, 1, statement_sudo.name, style_normal)
        worksheet_afi.set_column(0, 1, 30)
        #     WORKDAY
        worksheet_afi.write(2, 0, 'WORKDAY_ID', style_highlight)
        worksheet_afi.set_column(2, 0, 30)
        worksheet_afi.write(2, 1, statement_sudo.partner_id.workday_id,
                            style_normal)
        worksheet_afi.set_column(2, 1, 30)

        # Cosecha
        worksheet_afi.write(0, 3, 'Cosecha', style_highlight)
        worksheet_afi.set_column(0, 3, 30)
        worksheet_afi.write(0, 4, statement_sudo.harvest, style_normal)
        worksheet_afi.set_column(0, 4, 30)
        # Division
        worksheet_afi.write(1, 3, 'Mes Depósito:', style_highlight)
        worksheet_afi.set_column(1, 3, 30)
        worksheet_afi.write(1, 4, statement_sudo.deposit_month, style_normal)
        worksheet_afi.set_column(1, 4, 30)

    def report_firts_page_dm(self, workbook, statement_sudo):
        worksheet_afi = workbook.add_worksheet(
            statement_sudo.partner_id.name
        )
        style_highlight = workbook.add_format(
            {
                'bold': True,
                'pattern': 1,
                'bg_color': '#E0E0E0',
                'align': 'center'
            }
        )
        style_normal = workbook.add_format({'align': 'center'})
        # Nombre
        worksheet_afi.write(0, 0, 'WORKDAY_ID_DM', style_highlight)
        worksheet_afi.set_column(0, 0, 30)
        worksheet_afi.write(0, 1, statement_sudo.partner_id.workday_id,
                            style_normal)
        worksheet_afi.set_column(0, 1, 30)
        #     Division
        worksheet_afi.write(1, 0, 'Nombre DM', style_highlight)
        worksheet_afi.set_column(1, 0, 30)
        worksheet_afi.write(1, 1, statement_sudo.name, style_normal)
        worksheet_afi.set_column(1, 1, 30)
        #     Division
        worksheet_afi.write(2, 0, 'DIVISION', style_highlight)
        worksheet_afi.set_column(2, 0, 30)
        worksheet_afi.write(2, 1, statement_sudo.division, style_normal)
        worksheet_afi.set_column(2, 1, 30)
        #     Num rm
        worksheet_afi.write(3, 0, 'Número de RM', style_highlight)
        worksheet_afi.set_column(3, 0, 30)
        worksheet_afi.write(3, 1, statement_sudo.number_of_rm, style_normal)
        worksheet_afi.set_column(3, 1, 30)

        # Cosecha
        worksheet_afi.write(0, 3, 'Mes de Pago', style_highlight)
        worksheet_afi.set_column(0, 3, 30)
        worksheet_afi.write(0, 4, statement_sudo.harvest, style_normal)
        worksheet_afi.set_column(0, 4, 30)
        # Mes a Pagar
        worksheet_afi.write(1, 3, 'Mes a Pagar', style_highlight)
        worksheet_afi.set_column(1, 3, 30)
        worksheet_afi.write(1, 4, statement_sudo.deposit_month, style_normal)
        worksheet_afi.set_column(1, 4, 30)

    def instalations_membership(self, workbook, statement_sudo,
                                commission_lines):
        # Instaladas
        worksheet_afi = workbook.add_worksheet(
            'Instaladas'
        )
        style_highlight = workbook.add_format(
            {
                'bold': True,
                'pattern': 1,
                'bg_color': '#E0E0E0',
                'align': 'center'
            }
        )
        style_normal = workbook.add_format({'align': 'center'})
        row = 0
        headers = [
            "No.",
            "# Afiliación",
            "Nombre Comercial",
            "Fecha de Instalación",
            "Origen"
        ]
        rows = []
        for index, line in enumerate(commission_lines):
            line_statement = line.sudo()
            rows.append((
                index + 1,
                line_statement.membership_id.number_membership_trade,
                line_statement.membership_id.trade_name,
                line_statement.membership_id.date_install and
                line_statement.membership_id.date_install.strftime(
                    "%d/%m/%Y"
                ) or '',
                line_statement.membership_id.segment,
            ))

        for col, header in enumerate(headers):
            worksheet_afi.write(row, col, header, style_highlight)
            worksheet_afi.set_column(col, col, 30)
        for row, employee_row in enumerate(rows, start=1):
            for col, employee_data in enumerate(employee_row):
                worksheet_afi.write(row, col, employee_data, style_normal)

    def payed_membership(
            self, sheet_name, workbook, statement_sudo, commission_lines
    ):
        # pagadas
        worksheet_payed = workbook.add_worksheet(
            sheet_name
        )
        style_highlight = workbook.add_format(
            {
                'bold': True,
                'pattern': 1,
                'bg_color': '#E0E0E0',
                'align': 'center'
            }
        )
        style_normal = workbook.add_format({'align': 'center'})
        row = 0
        headers = [
            "No.",
            "# Afiliación",
            "Nombre Comercial",
            "RFC",
            "Fecha de Activación",
            "Origen",
            "Volumen",
            "Transacciones",
            "Porcentaje",
            "Rentabilidad",
            "Comisión",
        ]
        rows = []
        for index, line in enumerate(commission_lines):
            line_statement = line.sudo()
            rows.append((
                index + 1,
                line_statement.membership_id.number_membership_trade,
                line_statement.membership_id.trade_name,
                line_statement.membership_id.trade_rfc,
                line_statement.membership_id.activation_date and
                line_statement.membership_id.activation_date.strftime(
                    "%d/%m/%Y"
                ) or '',
                line_statement.membership_id.segment,
                line_statement.total_bills,
                line_statement.tx_month,
                str(float(line_statement.percentage * 100)) + '%',
                line_statement.dia,
                line_statement.amount,
            ))

        for col, header in enumerate(headers):
            worksheet_payed.write(row, col, header, style_highlight)
            worksheet_payed.set_column(col, col, 30)
        for row, employee_row in enumerate(rows, start=1):
            for col, employee_data in enumerate(employee_row):
                worksheet_payed.write(row, col, employee_data, style_normal)
