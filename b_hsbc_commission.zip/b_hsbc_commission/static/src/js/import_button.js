odoo.define('b_hsbc_commission.import_button', function(require) {
    "use strict";

    var core = require('web.core');
    var _t = core._t;
    var ListController = require('web.ListController');
    var ListView = require('web.ListView');
    var ListRenderer = require('web.ListRenderer');
    var viewRegistry = require('web.view_registry');

    var CommissionsFileUploadController = ListController.extend({
        buttons_template: 'CommissionsFileUpload.buttons',
        events: _.extend({}, ListController.prototype.events, {
            'click .btn_commissions_file_uploaded': 'upload_files_action',
            'click .btn_commissions_execute_actions': 'execute_processes_importation',
        }),

        execute_processes_importation: function() {
            var self = this;
            var state = self.model.get(self.handle, {raw: true});
            this.do_action({
                title: _t('Execute Automatic Process'),
                type: 'ir.actions.act_window',
                res_model: 'commission.execute.automatic.process.wizard',
                target: 'new',
                views: [[false, 'form']],
                context: state.getContext(),
                },
                {
                on_close: function () {
                    self.trigger_up('reload');
                }}
            );
        },
        upload_files_action: function() {
            var self = this;
            var state = self.model.get(self.handle, {raw: true});
            this.do_action({
                title: _t('Upload Files Wizard'),
                type: 'ir.actions.act_window',
                res_model: 'commission.file.upload.wizard',
                target: 'new',
                views: [[false, 'form']],
                context: state.getContext(),
                },
                {
                on_close: function () {
                    self.trigger_up('reload');
                }}
            );
        }
    });

    var CommissionsFileUploadView = ListView.extend({
        config: _.extend({}, ListView.prototype.config, {
            Renderer: ListRenderer,
            Controller: CommissionsFileUploadController,
        }),
    });
    viewRegistry.add('commission_file_upload', CommissionsFileUploadView);
});
