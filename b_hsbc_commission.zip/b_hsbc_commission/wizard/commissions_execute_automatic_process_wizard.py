from odoo import _, fields, models
from odoo.exceptions import ValidationError
import logging
_logger = logging.getLogger(__name__)


class CommissionExecuteAutoProcessWizard(models.TransientModel):
    _name = 'commission.execute.automatic.process.wizard'
    _description = 'Commission Execute Auto Process Wizard'

    definitive = fields.Boolean(default=True)

    def action_execute_auto_process(self):
        commission = self.env['commission.file.loaded']
        files_uploaded = commission.search(
            [
                ('state', 'in', ['uploaded', 'progress'])
            ]
        )
        if len(files_uploaded) != 5:
            raise ValidationError(
                _(
                    'To execute the Auto Process Wizard, you '
                    'must have four files in uploaded state.'
                )
            )
        employees = files_uploaded.filtered(
            lambda x: x.file_type == 'employees' and x.loading_message == 'La importación fue satisfactoria'
        )
        goal_dm = files_uploaded.filtered(lambda x: x.file_type == 'goal_dm' and x.loading_message == 'La importación fue satisfactoria')
        month_info = files_uploaded.filtered(lambda x: x.file_type == 'month_info' and x.loading_message == 'La importación fue satisfactoria')
        status_files = files_uploaded.filtered(
            lambda x: x.file_type == 'status_files' and x.loading_message == 'La importación fue satisfactoria'
        )
        memberships_maximum_rates = files_uploaded.filtered(
            lambda x: x.file_type == 'maximum_rates' and x.loading_message == 'La importación fue satisfactoria'
        )
        if not all([goal_dm, status_files, month_info, employees, memberships_maximum_rates]):
            raise ValidationError(
                _(
                    'To execute the Auto Process Wizard, you '
                    'must have four files in uploaded state and one per kind.'
                    'Please check for possible error messages in the Load Message column.'
                )
            )
        #memberships_maximum_rates.execute_memberships_maximum_rates_file()
        employees.execute_employees_file()
        goal_dm.execute_goal_dm_file()
        status_files.execute_status_files_file(previous_records=True)
        month_info.execute_month_info_file()
        if self.definitive:
            employees.state = 'computed'
            goal_dm.state = 'computed'
            month_info.state = 'computed'
            status_files.state = 'computed'
            memberships_maximum_rates.state = 'computed'
            employees.definitive = True
            goal_dm.definitive = True
            month_info.definitive = True
            status_files.definitive = True
            memberships_maximum_rates.definitive = True
        return True
