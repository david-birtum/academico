from odoo import _, api, fields, models
import logging
_logger = logging.getLogger(__name__)


class CommissionFileUploadWizard(models.TransientModel):
    _name = 'commission.file.upload.wizard'
    _description = 'Commission File Loaded'

    month_info = fields.Char(
        "Month Info Filename"
    )
    file_month_info = fields.Binary(
        "File Month Info"
    )
    status_files = fields.Char(
        "Status Files Filename"
    )
    file_status_files = fields.Binary(
        "File Status Files"
    )
    goal_dm = fields.Char(
        "Goal DM Filename"
    )
    file_goal_dm = fields.Binary(
        "File Goal DM"
    )
    employees = fields.Char(
        "Employees Filename"
    )
    file_employees = fields.Binary(
        "File Employees"
    )
    membership_maximum_rate = fields.Char(
        "Memberships with maximum Rate",
        help='For File that contains the Memberships with Maximum Rate',
    )
    file_membership_maximum_rate = fields.Binary(
        "File Memberships whith Maximum Rate",
        help="Memberships whith Maximum Rate",
    )

    @api.model
    def _get_file_upload_data(self, file, filename, file_type):
        return {
            'filename': filename,
            'file_content': file,
            'date': fields.Datetime.now(),
            'state': 'uploaded',
            'file_type': file_type,
            'definitive': False,
            'loading_message': _("Upload was successful"),
        }

    def action_import_files(self):
        commission = self.env['commission.file.loaded']
        for wizard in self:
            if wizard.file_month_info and wizard.month_info:
                commission_id = commission.create(
                    self._get_file_upload_data(
                        wizard.file_month_info,
                        wizard.month_info,
                        'month_info'
                    )
                )
                commission_id._read_xls()
            if wizard.file_status_files and wizard.status_files:
                commission_id = commission.create(
                    self._get_file_upload_data(
                        wizard.file_status_files,
                        wizard.status_files,
                        'status_files'
                    )
                )
                commission_id._read_xls()
            if wizard.file_goal_dm and wizard.goal_dm:
                commission_id = commission.create(
                    self._get_file_upload_data(
                        wizard.file_goal_dm,
                        wizard.goal_dm,
                        'goal_dm'
                    )
                )
                commission_id._read_xls()
            if wizard.file_employees and wizard.employees:
                commission_id = commission.create(
                    self._get_file_upload_data(
                        wizard.file_employees,
                        wizard.employees,
                        'employees'
                    )
                )
                commission_id._read_xls()
            if wizard.file_membership_maximum_rate and wizard.membership_maximum_rate:
                commission_id = commission.create(
                    self._get_file_upload_data(
                        wizard.file_membership_maximum_rate,
                        wizard.membership_maximum_rate,
                        'maximum_rates'
                    )
                )
                commission_id._read_xls()
