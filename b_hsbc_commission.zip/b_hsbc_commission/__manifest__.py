# Module written to Odoo, Open Source Management Solution
#
# Copyright (c) 2019 Birtum - http://www.birtum.com/
# All Rights Reserved.
# Developer(s): José Angel Inda Herrera
#               (jai@wedoo.tech)
########################################################################
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
########################################################################
{
    'name': 'BIRTUM | HSBC Commissions',
    'author': 'BIRTUM ©',
    'category': 'Sales/Commissions',
    'website': 'https://www.birtum.com',
    'license': 'GPL-3',
    'summary': """
BIRTUM | HSBC Commissions
------------------------------------------
This module was created to Manager commissions to HSBC.. 
        """,
    'version': '14.0.0.0.1',
    'depends': [
        'base',
        'contacts',
        'portal',
        'website'
    ],
    'external_dependencies': {
        'python': ['xlrd'],
    },
    'data': [
        'security/ir.model.access.csv',
        'data/commission.membership.percentage.csv',
        'security/res_groups.xml',
        'data/paperformat.xml',
        'views/assets_common.xml',
        'views/assets_backend.xml',
        'views/inherit_res_partner_views.xml',
        'views/commission_account_rm_views.xml',
        'views/commission_account_dm_views.xml',
        'views/commission_account_enterprise_views.xml',
        'views/commission_account_reporting_views.xml',
        'views/commission_file_loaded_views.xml',
        'views/commission_membership_percentage_views.xml',
        'views/commission_file_loaded_computed_views.xml',
        'views/commission_file_loaded_dm_team_views.xml',
        'views/commission_file_loaded_employees_views.xml',
        'views/commission_file_loaded_files_status_views.xml',
        'views/commission_file_loaded_maximum_rates_views.xml',
        'views/commission_membership_views.xml',
        'views/commission_files_status_views.xml',
        'views/commission_partner_membership_views.xml',
        'views/commission_dm_team_views.xml',
        'views/report_rm.xml',
        'views/account_report.xml',
        'views/res_config_settings_views.xml',
        'views/menu_commissions.xml',
        'views/template_website.xml',
        'wizard/commissions_file_upload_wizard_views.xml',
        'wizard/commissions_execute_automatic_process_wizard_views.xml',
    ],
    'demo': [
    ],
    'qweb': [
        'static/src/xml/import_button.xml'
    ],
    'application': True,
    'installable': True,
}
