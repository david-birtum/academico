from odoo import fields, models, api


class CommissionFilesStatus(models.Model):
    _name = 'commission.files.status'
    _description = 'Commission Files Status'

    membership = fields.Char()
    status = fields.Char('Status')

    @api.model
    def is_inactive(self, membership):
        if self.search([('membership', '=', membership)], limit=1):
            return True
        return False
