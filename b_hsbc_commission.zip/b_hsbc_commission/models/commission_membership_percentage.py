from odoo import fields, models, api

import logging
_logger = logging.getLogger(__name__)


class CommissionMembershipPercentage(models.Model):
    _name = 'commission.membership.percentage'
    _description = 'Commission Membership Percentage'

    membership_installed = fields.Integer()
    percentage = fields.Float()

    @api.model
    def get_percentage_by_member_qty(self, quantity):
        """
        Get the percentage by membership quantity.
        """
        membership_percentage = self.search([
            ('membership_installed', '<=', quantity)
        ], order='membership_installed desc', limit=1)

        if membership_percentage:
            return membership_percentage.percentage
        elif not membership_percentage and quantity > 0:
            first_percentage = self.search(
                [], order='membership_installed asc', limit=1
            )
            return first_percentage and first_percentage.percentage or 0
        return 0.0
