        # Copyright 2017 ForgeFlow S.L.
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl)
from odoo import fields, models


class PartnerCommissionPosition(models.Model):
    _name = 'partner.commission.position'
    _description = 'Partner Commission Position'

    name = fields.Char()
