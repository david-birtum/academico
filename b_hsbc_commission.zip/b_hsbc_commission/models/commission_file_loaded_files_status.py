from odoo import fields, models


class CommissionFileLoadedFilesStatus(models.Model):
    _name = 'commission.file.loaded.files.status'
    _description = 'Commission File Loaded Files Status'

    membership = fields.Char()
    status = fields.Char('Status')
    file_uploaded_id = fields.Many2one(
        'commission.file.loaded'
    )
