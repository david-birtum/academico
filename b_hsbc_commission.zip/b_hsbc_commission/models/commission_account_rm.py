from odoo import fields, models
import logging
_logger = logging.getLogger(__name__)


class CommissionAccountRM(models.Model):
    _name = 'commission.account.rm'
    _description = 'Commission Account RM'
    _inherit = 'commission.currency.abstract'

    deposit_date = fields.Datetime()
    deposit_month = fields.Char()
    harvest = fields.Char()
    partner_id = fields.Many2one(
        'res.partner'
    )
    partner_number = fields.Char(
        related='partner_id.number',
        store=True
    )
    workday_id = fields.Char(
        related='partner_id.workday_id',
        store=True
    )
    name = fields.Char(
        related='partner_id.name',
        store=True
    )
    partner_dm_id = fields.Many2one(
        'res.partner'
    )
    partner_dm_workday_id = fields.Char(
        related='partner_dm_id.workday_id',
        string="Workday ID DM",
        store=True
    )
    rfc = fields.Char()
    file_uploaded_id = fields.Many2one(
        'commission.file.loaded',
        ondelete='cascade'
    )
    commission_id = fields.Many2one(
        'commission.partner.membership'
    )
    commission_pending_id = fields.Many2one(
        'commission.partner.membership'
    )
    # TODO: division, Para que se utiliza este campo y de donde sale
    division = fields.Char()
    percentage = fields.Float()
    commission = fields.Float(digits=(16, 2))
    xls_file = fields.Binary(string="XLS file")
    xls_filename = fields.Char()

    def _get_report_base_filename(self):
        self.ensure_one()
        return 'Estado de Cuenta RM'