from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    gptm_commission = fields.Float()
    referred_commission = fields.Float()
    rentability_day = fields.Float()
    rm_percentage = fields.Float()
    dm_percentage = fields.Float()
    goal_by_month = fields.Integer()
    execution_months = fields.Integer()
    percent_commission_up = fields.Float()
    percent_commission_down = fields.Float()
    percent_enterprise = fields.Float(
        string='Percentage for enterprise users',
        help='Percentage used for enterprise user commission calculations'
    )
    rm_maximum_rate_percentage = fields.Float(
        string='RM commission percentage',
        help = 'RM commission percentage for Maximum Rate'
    )
    dm_maximum_rate_percentage = fields.Float(
        string='DM commission percentage',
        help = 'DM commission percentage for Maximum Rate'
    )

    @api.model
    def get_values(self):
        res = super(ResConfigSettings, self).get_values()

        res['gptm_commission'] = self.env[
            'ir.config_parameter'
        ].sudo().get_param('b_hsbc_commission.gptm_commission')
        res['referred_commission'] = self.env[
            'ir.config_parameter'
        ].sudo().get_param('b_hsbc_commission.referred_commission')
        res['rentability_day'] = self.env[
            'ir.config_parameter'
        ].sudo().get_param('b_hsbc_commission.rentability_day')
        res['rm_percentage'] = self.env[
            'ir.config_parameter'
        ].sudo().get_param('b_hsbc_commission.rm_percentage')
        res['dm_percentage'] = self.env[
            'ir.config_parameter'
        ].sudo().get_param('b_hsbc_commission.dm_percentage')
        res['goal_by_month'] = self.env[
            'ir.config_parameter'
        ].sudo().get_param('b_hsbc_commission.goal_by_month')
        res['percent_commission_up'] = self.env[
            'ir.config_parameter'
        ].sudo().get_param('b_hsbc_commission.percent_commission_up')
        res['percent_commission_down'] = self.env[
            'ir.config_parameter'
        ].sudo().get_param('b_hsbc_commission.percent_commission_down')
        res['execution_months'] = self.env[
            'ir.config_parameter'
        ].sudo().get_param('b_hsbc_commission.execution_months')
        res['percent_enterprise'] = self.env[
            'ir.config_parameter'
        ].sudo().get_param('b_hsbc_commission.percent_enterprise')
        res['rm_maximum_rate_percentage'] = self.env[
            'ir.config_parameter'
        ].sudo().get_param('b_hsbc_commission.rm_maximum_rate_percentage')
        res['dm_maximum_rate_percentage'] = self.env[
            'ir.config_parameter'
        ].sudo().get_param('b_hsbc_commission.dm_maximum_rate_percentage')
        return res

    @api.model
    def set_values(self):
        self.env['ir.config_parameter'].sudo().set_param(
            'b_hsbc_commission.gptm_commission',
            self.gptm_commission
        )
        self.env['ir.config_parameter'].sudo().set_param(
            'b_hsbc_commission.referred_commission',
            self.referred_commission
        )
        self.env['ir.config_parameter'].sudo().set_param(
            'b_hsbc_commission.rentability_day',
            self.rentability_day
        )
        self.env['ir.config_parameter'].sudo().set_param(
            'b_hsbc_commission.rm_percentage',
            self.rm_percentage
        )
        self.env['ir.config_parameter'].sudo().set_param(
            'b_hsbc_commission.dm_percentage',
            self.dm_percentage
        )
        self.env['ir.config_parameter'].sudo().set_param(
            'b_hsbc_commission.goal_by_month',
            self.goal_by_month
        )
        self.env['ir.config_parameter'].sudo().set_param(
            'b_hsbc_commission.percent_commission_up',
            self.percent_commission_up
        )
        self.env['ir.config_parameter'].sudo().set_param(
            'b_hsbc_commission.percent_commission_down',
            self.percent_commission_down
        )
        self.env['ir.config_parameter'].sudo().set_param(
            'b_hsbc_commission.execution_months',
            self.execution_months
        )
        self.env['ir.config_parameter'].sudo().set_param(
            'b_hsbc_commission.percent_enterprise',
            self.percent_enterprise
        )
        self.env['ir.config_parameter'].sudo().set_param(
            'b_hsbc_commission.rm_maximum_rate_percentage',
            self.rm_maximum_rate_percentage
        )
        self.env['ir.config_parameter'].sudo().set_param(
            'b_hsbc_commission.dm_maximum_rate_percentage',
            self.dm_maximum_rate_percentage
        )
        super(ResConfigSettings, self).set_values()
