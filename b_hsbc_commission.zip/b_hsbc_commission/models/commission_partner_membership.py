from odoo import fields, models, api
import logging

_logger = logging.getLogger(__name__)


class CommissionPartnerMembership(models.Model):
    _name = 'commission.partner.membership'
    _description = 'Commission Partner Membership'
    _inherit = 'commission.currency.abstract'
    _rec_name = 'partner_id'

    partner_id = fields.Many2one(
        'res.partner'
    )
    active = fields.Boolean(default=True)
    workday_id = fields.Char()
    date = fields.Datetime()
    count_membership = fields.Integer()
    total_rm = fields.Integer()
    percentage = fields.Float()
    amount_commission = fields.Float(
        compute='_compute_amount_commission',
        digits=(16, 2)
    )
    category_select = fields.Selection(
        [
            ('dm', 'DM'),
            ('rm', 'RM'),
            ('manager', 'Manager'),
        ],
        default='rm'
    )
    state = fields.Selection(
        [
            ('draft', "Draft"),
            ('pending', "Pending"),
            ('payed', "Payed"),
        ], default='draft'
    )
    line_ids = fields.One2many(
        'commission.partner.membership.line',
        'commission_id',
    )
    file_uploaded_id = fields.Many2one(
        'commission.file.loaded',
        ondelete='cascade'
    )

    @api.depends('line_ids')
    def _compute_amount_commission(self):
        for record in self:
            if record.state == 'pending':
                record.amount_commission = sum(
                    record.line_ids.filtered(
                        lambda x: x.commission_status in ['pending']
                    ).mapped('amount')
                )
            else:
                record.amount_commission = sum(
                    record.line_ids.filtered(
                        lambda x: x.commission_status in ['success', 'failure']
                    ).mapped('amount')
                )
    #Testing purposes
    # @api.model
    # def create(self, values):
    #     """Override default Odoo create function and extend."""
    #     obj = super(CommissionPartnerMembership, self).create(values)
    #     print("COMISION CREADA",obj.id)
    #     return obj


class CommissionPartnerMembershipLine(models.Model):
    _name = 'commission.partner.membership.line'
    _description = 'Commission Partner Membership Line'
    _inherit = 'commission.currency.abstract'

    commission_id = fields.Many2one(
        'commission.partner.membership',
        ondelete='cascade'
    )
    origin_commission = fields.Many2one(
        'commission.partner.membership'
    )
    membership_id = fields.Many2one(
        'commission.membership'
    )
    commission_status = fields.Selection(
        [
            ('success', 'Success'),
            ('failure', 'Failure'),
            ('pending', 'Pending'),
        ]
    )
    is_success = fields.Boolean()
    amount = fields.Float(
        compute='_compute_amount_commission',
        digits=(16, 2))
    percentage = fields.Float()
    dia = fields.Float(digits=(16, 2))
    count_membership = fields.Integer()
    partner_id = fields.Many2one(
        'res.partner'
    )
    tx_month = fields.Integer()
    total_bills = fields.Float(digits=(16, 2))
    rfc = fields.Char()
    membership_line = fields.Many2one(
        'commission.membership.line',
    )
    membership_file_info = fields.Selection(
        [
            ('init', 'Initiated with file'),
            ('without', 'Without File'),
            ('subsequently', 'File was subsequently delivered'),
        ],
        
        help='Para cada línea de comisión se consideran 3 casos, la afiliación se creó con expediente, que aún no se entrega expediente (el registro ya se copio) o que posteriormente se entrega'
    )
    maximum_rate = fields.Boolean(
        string="Maximum Rate",
        help="Membership whith Maximum Rate",
        )

    @api.depends('dia', 'percentage')
    def _compute_amount_commission(self):
        min_rentability = float(
            self.env['ir.config_parameter'].sudo().get_param(
                'b_hsbc_commission.rentability_day')) / \
                          int(
                              self.env[
                                  'ir.config_parameter'
                              ].sudo().get_param(
                                  'b_hsbc_commission.execution_months'
                              )
                          )
        percent_enterprise_config = float(
            self.env['ir.config_parameter'].sudo().get_param(
                'b_hsbc_commission.percent_enterprise'
            )
        )
        for member in self:
            if member.commission_id.partner_id.category_select == 'em':
                member.amount = member.dia * percent_enterprise_config
            else:
                referred_commission = float(
                    self.env['ir.config_parameter'].sudo().get_param(
                        'b_hsbc_commission.referred_commission'
                    )
                )
                rentability = member.dia if member.membership_id.segment != \
                                            'REFERIDO' \
                    else member.dia * referred_commission
                if member.commission_id.partner_id.category_select != "rm" and \
                        rentability >= min_rentability or \
                        member.commission_id.partner_id.category_select == "rm" \
                        or rentability < 0:
                    member.amount = rentability * member.percentage
                else:
                    member.amount = 0
