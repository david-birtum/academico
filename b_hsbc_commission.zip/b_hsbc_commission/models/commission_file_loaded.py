from odoo import _, fields, models, api
import base64
from datetime import datetime, time
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
import calendar
from pytz import UTC, timezone

from odoo.exceptions import UserError, ValidationError
import logging

_logger = logging.getLogger(__name__)
try:
    import xlrd
except (ImportError, IOError) as err:
    _logger.debug(err)


class CommissionFileLoaded(models.Model):
    '''
    Después de importar los archivos mediante un wizard, la infomación se extrae y es guardada en este modelo, 
    un registro por cada archivo
    '''
    _name = 'commission.file.loaded'
    _description = 'Commission File Loaded'
    _inherit = 'commission.currency.abstract'

    filename = fields.Char(
        "Filename"
    )
    file_content = fields.Binary(
        "File"
    )
    file_type = fields.Selection(
        [
            ('month_info', 'Month Info'),
            ('status_files', 'Status Files'),
            ('goal_dm', 'Goal DM'),
            ('employees', 'Employees'),
            ('maximum_rates', 'Memberships whit Maximum Rates'),
        ],
        help="* Month Info: El registro corresponde a un archivo con información de las Afiliaciones del mes que se está cargando"
             "\n* Status Files: El registro corresponde a un archivo con información de las Afiliaciones Sin Expediente del mes que se está cargando"
             "\n* goal_dm: El registro corresponde a un archivo con información de las Metas del mes que se está cargando"
             "\n* Employees: El registro corresponde a un archivo con información de los empleados del mes que se está cargando"
    )
    date = fields.Datetime(
        "Upload Date",
    )
    state = fields.Selection(
        [
            ('uploaded', 'Uploaded'),
            ('progress', 'In-Progress'),
            ('computed', 'Computed'),
            ('error', 'Error'),
        ],
            help="* Uploaded: El archivo se ha importado desde el Wizard (o se ejecutó el Procesamiento siendo No Definitivo)"
             "\n* In-Progress: "
             "\n* Computed: Los archivos se procesaron utilizando la opción Definitivo"
             "\n* Error: Error al cargar-procesar?"
    )
    definitive = fields.Boolean(
        string='Definitive',
        help='El archivo se procesó con la opción Definitivo, los datos se cargaron de forma permanente'
    )
    loading_message = fields.Text(
        string='Loading Message',
        help='Mensaje mostrado al cargar o procesar el archivo',
    )
    file_computed = fields.One2many(
        'commission.file.loaded.computed',
        'file_uploaded_id',
        string="Data from Load File",
        help="Cada elemento de la lista es un registro leido del Archivo de Carga"
    )
    file_dm_team = fields.One2many(
        'commission.file.loaded.dm.team',
        'file_uploaded_id',
        string="Data from DM file",
        help="Cada elemento de la lista es un registro leido del Archivo de Metas"
    )
    file_employees = fields.One2many(
        'commission.file.loaded.employees',
        'file_uploaded_id',
        string="Data from Employees",
        help="Cada elemento de la lista es un registro leido del archivo de Empleados"
    )
    file_status_files = fields.One2many(
        'commission.file.loaded.files.status',
        'file_uploaded_id',
        string = "Data from Documentation",
        help="Cada elemento de la lista es un registro leido del archivo de Expedientes"

    )
    file_maximum_rates_files = fields.One2many(
        'commission.file.loaded.maximum.rates',
        'file_uploaded_id',
        string='Maximum rate data',
        help='Memberships with maximum rates read from Excel file',
    )

    def unlink(self):
        """
        It deletes the files that are uploaded.
        :return: The super method is being returned.
        """
        """Unlink   a transaction"""
        for computed in self:
            # if computed.state == 'computed':
            #     raise ValidationError(
            #         _('You can not delete a computed line')
            #     )
            computed.file_computed.unlink()
            computed.file_dm_team.unlink()
            computed.file_employees.unlink()
            computed.file_status_files.unlink()
            computed.file_maximum_rates_files.unlink()
        return super(CommissionFileLoaded, self).unlink()

    def _read_xls(self):
        """
        It reads an excel file, and creates a record in the database for each row in
        the excel file
        """
        tz = self.env.user.tz
        book = xlrd.open_workbook(
            file_contents=base64.decodebytes(self.file_content) or b''
        )
        sheets = book.sheet_names()
        sheet_name = sheets[0]
        sheet = book.sheet_by_name(sheet_name)
        for row_index, row in enumerate(map(sheet.row, range(sheet.nrows)), 1):
            if row_index == 1:
                continue
            values = {}
            if self.file_type == 'month_info':
                try:
                    values['workday_id_dm'] = row[0].value
                    values['division'] = row[1].value
                    values['segment'] = row[2].value
                    values['employee_number_manager'] = row[3].value
                    values['workday_id'] = row[4].value
                    values['name_rm_gptm'] = row[5].value
                    values['number_membership_trade'] = str(int(row[6].value))
                    values['trade_name'] = row[7].value
                    values['trade_rfc'] = row[8].value
                    values['mcc'] = row[9].value
                    values['family'] = row[10].value
                    values['credit_discount'] = float(row[11].value or 0.0) / 100
                    values['debit_discount'] = float(row[12].value or 0.0) / 100
                    values['credit_exchange_rate'] = float(
                        row[13].value or 0.0
                    ) / 100
                    values['debit_exchange_rate'] = float(row[14].value or 0.0) / 100
                    dt = datetime(
                        *xlrd.xldate.xldate_as_tuple(
                            row[15].value, book.datemode)
                    )
                    dt = timezone(tz).localize(dt).astimezone(UTC)
                    values['date_install'] = dt.strftime(
                        DEFAULT_SERVER_DATETIME_FORMAT
                    )
                    dt = datetime(
                        *xlrd.xldate.xldate_as_tuple(
                            row[16].value, book.datemode)
                    )
                    dt = timezone(tz).localize(dt).astimezone(UTC)
                    values['dia_date'] = dt.strftime(
                        DEFAULT_SERVER_DATETIME_FORMAT
                    )
                    dt = datetime(
                        *xlrd.xldate.xldate_as_tuple(
                            row[17].value, book.datemode)
                    )
                    dt = timezone(tz).localize(dt).astimezone(UTC)
                    values['deposit_date'] = dt.strftime(
                        DEFAULT_SERVER_DATETIME_FORMAT
                    )
                    dt = datetime(
                        *xlrd.xldate.xldate_as_tuple(
                            row[18].value, book.datemode)
                    )
                    dt = timezone(tz).localize(dt).astimezone(UTC)
                    values['counted_date'] = dt.strftime(
                        DEFAULT_SERVER_DATETIME_FORMAT
                    )
                    values['tx_month'] = row[19].value or 0
                    values['total_bills'] = row[20].value or 0
                    values['rentability'] = row[21].value
                    values['file_uploaded_id'] = self.id
                    self.env['commission.file.loaded.computed'].create(values)
                except Exception as e:
                    self.loading_message += f'\n {str(e)}'
                    _logger.error(f'A error encountered : {e} ')
            elif self.file_type == 'status_files':
                try:
                    values['membership'] = str(int(row[0].value))
                    values['status'] = row[1].value
                    values['file_uploaded_id'] = self.id
                    self.env['commission.file.loaded.files.status'].create(
                        values
                    )
                except Exception as e:
                    self.loading_message += f'\n {str(e)}'
                    _logger.error(f'A error encountered : {e} ')
            elif self.file_type == 'goal_dm':
                try:
                    values['workday_id'] = row[0].value
                    values['name'] = row[1].value
                    values['current_members'] = row[2].value
                    values['goal_members'] = row[3].value
                    values['file_uploaded_id'] = self.id
                    values['date'] = fields.Datetime.now()
                    self.env['commission.file.loaded.dm.team'].create(values)
                except Exception as e:
                    self.loading_message += f'\n {str(e)}'
                    _logger.error(f'A error encountered : {e} ')
            elif self.file_type == 'employees':
                try:
                    values['category_select'] = row[0].value.lower()
                    position_id = self.env[
                                      'partner.commission.position'
                                  ].search(
                        [
                            ('name', '=', row[1].value.strip())
                        ], limit=1
                    ) or self.env['partner.commission.position'].create(
                        {
                            'name': row[1].value.strip()
                        }
                    )
                    values['position_id'] = position_id.id
                    values['name'] = row[2].value
                    values['workday_id'] = row[3].value
                    values['division'] = row[4].value
                    values['workday_superior'] = row[5].value
                    values['email'] = row[6].value
                    values['file_uploaded_id'] = self.id
                    self.env['commission.file.loaded.employees'].create(values)
                except Exception as e:
                    self.loading_message += f'\n {str(e)}'
                    _logger.error(f'A error encountered : {e} ')
            elif self.file_type == 'maximum_rates':
                try:
                    values['name'] = str(int(row[0].value))
                    values['file_uploaded_id'] = self.id
                    self.env['commission.file.loaded.maximum.rates'].create(values)
                except Exception as e:
                    self.loading_message += f'\n {str(e)}'
                    _logger.error(f'A error encountered : {e} ')

    @api.model
    def _get_file_uploaded_action(self, view_ref, title, res_model, object_id):
        """
        It returns an action that opens a new window with a tree view of the model
        specified in the function's parameters

        :param view_ref: the reference of the view you want to open
        :param title: The title of the action
        :param res_model: The model of the object you want to create
        :param object_id: the id of the object that you want to open the tree view
        for
        :return: A dictionary with the following keys:
            name: The title of the action
            type: The type of action
            view_mode: The view mode
            res_model: The model
            view_id: The view id
            domain: The domain
            context: The context
            target: The target
        """
        return {
            'name': _(title),
            'type': 'ir.actions.act_window',
            'view_mode': 'tree',
            'res_model': res_model,
            'view_id': self.env.ref(view_ref).id,
            'domain': [('file_uploaded_id', '=', self.id)],
            'context': {'default_file_uploaded_id': object_id},
            'target': 'new',
        }

    def view_uploaded_lines(self):
        """
        It returns an action that opens a view with the uploaded lines of the file
        :return: A dictionary with the following keys:
            'name': 'Status Files',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'commission.file.loaded.files.status',
            'views': [[False, '
        """
        self.ensure_one()
        if self.file_type == 'month_info':
            return self._get_file_uploaded_action(
                'b_hsbc_commission.commission_file_loaded_computed_tree',
                'Month Info',
                'commission.file.loaded.computed',
                self.id
            )
        elif self.file_type == 'status_files':
            view_ref = \
                'b_hsbc_commission.commission_file_loaded_files_status_tree'
            return self._get_file_uploaded_action(
                view_ref,
                'Status Files',
                'commission.file.loaded.files.status',
                self.id
            )
        elif self.file_type == 'goal_dm':
            return self._get_file_uploaded_action(
                'b_hsbc_commission.commission_file_loaded_dm_team_tree',
                'Goal DM',
                'commission.file.loaded.dm.team',
                self.id
            )
        elif self.file_type == 'employees':
            return self._get_file_uploaded_action(
                'b_hsbc_commission.commission_file_loaded_employees_tree',
                'Employees',
                'commission.file.loaded.employees',
                self.id
            )
        elif self.file_type == 'maximum_rates':
            return self._get_file_uploaded_action(
                'b_hsbc_commission.commission_file_loaded_maximum_rate_tree',
                'Memberships with maximum rate',
                'commission.file.loaded.maximum.rates',
                self.id
            )
        else:
            return {}

    #TODO Verificar si esta función quedó obsoleta
    def execute_uploaded_files(self):
        """
        It executes the file uploaded by the user, depending on the file type
        """
        for uploaded in self:
            if uploaded.state == 'computed':
                continue
            if uploaded.file_type == 'employees':
                uploaded.execute_employees_file()
            elif uploaded.file_type == 'month_info':
                uploaded.execute_month_info_file()
            elif uploaded.file_type == 'status_files':
                uploaded.execute_status_files_file()
            elif uploaded.file_type == 'goal_dm':
                uploaded.execute_goal_dm_file()
            else:
                raise UserError(
                    _('File type not supported')
                )
            if uploaded.definitive:
                uploaded.state = 'computed'

    def execute_goal_dm_file(self):
        """
        It creates a new record in the commission.dm.team table for each record in
        the commission.file.dm.team table that has the same file_uploaded_id as the
        current record
        """
        self.ensure_one()
        dm_team = self.env['commission.dm.team']
        dm_team.search(
            [
                ('file_uploaded_id', '=', self.id)
            ]
        ).unlink()
        values = [
            {
                'workday_id': file_dm.workday_id,
                'current_members': file_dm.current_members,
                'goal_members': file_dm.goal_members,
                'file_uploaded_id': file_dm.file_uploaded_id.id,
            } for file_dm in self.file_dm_team
        ]
        dm_team.create(values)

    @api.model
    def get_all_params(self):
        """
        It gets all the parameters from the database and returns them as a list
        :return: A list of the values of the parameters.
        """
        min_rentability = float(
            self.env['ir.config_parameter'].sudo().get_param(
                'b_hsbc_commission.rentability_day')) / \
                          int(
                              self.env[
                                  'ir.config_parameter'
                              ].sudo().get_param(
                                  'b_hsbc_commission.execution_months'
                              )
                          )
        min_percentage = float(
            self.env['ir.config_parameter'].sudo().get_param(
                'b_hsbc_commission.rm_percentage'
            )
        )
        referred_commission = float(
            self.env['ir.config_parameter'].sudo().get_param(
                'b_hsbc_commission.referred_commission'
            )
        )
        gptm_commission = float(
            self.env['ir.config_parameter'].sudo().get_param(
                'b_hsbc_commission.gptm_commission'
            )
        )
        goal_by_month = int(
            self.env['ir.config_parameter'].sudo().get_param(
                'b_hsbc_commission.goal_by_month'
            )
        )
        percent_commission_up = float(
            self.env['ir.config_parameter'].sudo().get_param(
                'b_hsbc_commission.percent_commission_up'
            )
        )
        percent_commission_down = float(
            self.env['ir.config_parameter'].sudo().get_param(
                'b_hsbc_commission.percent_commission_down'
            )
        )
        dm_percentage_config = float(
            self.env['ir.config_parameter'].sudo().get_param(
                'b_hsbc_commission.dm_percentage'
            )
        )
        percent_enterprise_config = float(
            self.env['ir.config_parameter'].sudo().get_param(
                'b_hsbc_commission.percent_enterprise'
            )
        )
        rm_max_rate = float(
            self.env['ir.config_parameter'].sudo().get_param(
                'b_hsbc_commission.rm_maximum_rate_percentage'
            )
        )
        dm_max_rate = float(
            self.env['ir.config_parameter'].sudo().get_param(
                'b_hsbc_commission.dm_maximum_rate_percentage'
            )
        )
        return [
            min_rentability,
            min_percentage,
            referred_commission,
            gptm_commission,
            goal_by_month,
            percent_commission_up,
            percent_commission_down,
            dm_percentage_config,
            percent_enterprise_config,
            rm_max_rate,
            dm_max_rate,
        ]

    def clear_commissions_created(self):
        """
        It deletes all the commission records that were created by the file upload
        """
        self.env['commission.partner.membership'].search(
            [('file_uploaded_id', '=', self.id)]
        ).unlink()

    def execute_month_info_file(self):
        """
        It creates a commission for the RM, DM and Enterprise based on the status of
        the membership
        """
        self.ensure_one()
        #Creación de nuevas afiliaciones o actualización de las existentes
        self.file_computed.execute_month_calculation()
        # self.execute_status_files_file()
        #TODO Al parecer esta función no se requiere pues el set de datos a borrar siempre es vacío
        self.clear_commissions_created()
        # ------------------------------------------------------------
        # From here it starts the process of creating the commissions
        # ------------------------------------------------------------
        commissions = {}
        percent_by_installation = self.env['commission.membership.percentage'] #Modelo de configuración con porcentajes de Comisión
        commission_partner = self.env['commission.partner.membership'] #Comisiones de empleados
        commission_membership = self.env['commission.membership'] #Modelo de afiliaciones
        account_rm = self.env['commission.account.rm']
        account_dm = self.env['commission.account.dm']
        account_ent = self.env['commission.account.enterprise']
        reporting = self.env['commission.reporting']
        min_rentability, min_percentage, \
        referred_commission, gptm_commission, goal_by_month, \
        percent_commission_up, \
        percent_commission_down, dm_percentage_config, percent_enterprise_config, rm_max_rate, dm_max_rate = self.get_all_params()
        #TODO Revisar si alguna vez estos sets regresan datos
        account_rm.search(
            [
                ('file_uploaded_id', '=', self.id),
            ]
        ).unlink()
        account_ent.search(
            [
                ('file_uploaded_id', '=', self.id),
            ]
        ).unlink()
        account_dm.search(
            [
                ('file_uploaded_id', '=', self.id),
            ]
        ).unlink()
        reporting.search(
            [
                ('file_uploaded_id', '=', self.id),
            ]
        ).unlink()
        workday_ids = list(set(self.file_computed.mapped('workday_id')))
        today = fields.Datetime.today()
        today_date = fields.Date.from_string(today) #TODO Tal vez esta variable ya no se usa
        dm = {}
        pending_dm = {}
        maximum_rates_memberships = self.get_memberships_with_maximum_rate()
        # Calculate the commissions for the workdays(employees RM)
        for workday_id in workday_ids:
            # All the membership for the workday_id
            info_by_workday_id = commission_membership.search(
                [
                    ('workday_id', '=', workday_id),
                    (
                        'number_membership_trade',
                        'in',
                        self.file_computed.mapped('number_membership_trade')
                    ),
                    ('current_month', '<=', 12)
                ]
            )
            # Find the partner for the workday_id
            partner_id = self.env['res.partner'].with_context(active_test=False).search(
                [
                    ('workday_id', '=', workday_id)
                ], limit=1
            )
            if not partner_id:
                continue
            # Quantity of memberships in month, only new memberships
            count_membership = commission_membership.search_count(
                [
                    ('workday_id', '=', workday_id),
                    (
                        'file_uploaded_id',
                        '=',
                        self.file_computed.file_uploaded_id.id
                    ),
                ]
            )
            percentage = percent_enterprise_config if partner_id.category_select == 'em' else percent_by_installation.get_percentage_by_member_qty(
                count_membership
            )
            #Un registro en commission.partner.membership para afiliaciones con Activas (Con expediente) y otro para afiliaciones sin expedientes
            commissions[workday_id] = {
                'success': {
                    'line_ids': [],
                    'count_membership': 1,
                    'file_uploaded_id': self.id,
                    'partner_id': partner_id.id,
                    'workday_id': workday_id,
                    'percentage': percentage,
                    'date': today,
                    'state': 'payed'
                },
                'without_files': {
                    'line_ids': [],
                    'count_membership': 1,
                    'partner_id': partner_id.id,
                    'file_uploaded_id': self.id,
                    'workday_id': workday_id,
                    'percentage': percentage,
                    'date': today,
                    'state': 'pending',
                },
            }
            total_amount_success = 0
            total_amount_failure = 0
            total_amount_without_files = 0
            for membership in info_by_workday_id:
                rentability = membership.line_ids[-1].rentability
                tx_month = membership.line_ids[-1].tx_month
                total_bills = membership.line_ids[-1].total_bills
                date_install = membership.date_install
                if datetime.now().month <= date_install.month:
                    continue
                segment = membership.segment
                if partner_id.category_select == 'em':
                    percent_calculation_1 = 1
                else:
                    percent_calculation_1 = referred_commission \
                        if segment.upper() == 'REFERIDO' \
                        else gptm_commission
                computed_1 = rentability * percent_calculation_1
                if self.env['commission.files.status'].is_inactive(
                        membership.number_membership_trade
                ):
                    percent_wof = percentage \
                        if computed_1 >= min_rentability \
                        else min_percentage
                    if rentability < 0 and membership.number_membership_trade in maximum_rates_memberships: #new condition for max rates TODO condicion de estar en el archivo de carga
                        percent_wof = rm_max_rate
                    computed_1 = computed_1 * percent_wof
                    commissions[workday_id][
                        'without_files'
                    ]['line_ids'].extend([(0, 0, {
                        'amount': computed_1,
                        'percentage': percent_enterprise_config if partner_id.category_select == 'em' else percent_wof,
                        'membership_id': membership.id,
                        'rfc': membership.trade_rfc,
                        'is_success':
                            True if computed_1 >= min_rentability else False,
                        'dia': rentability,
                        'tx_month': tx_month,
                        'total_bills': total_bills,
                        'partner_id': partner_id.id,
                        'count_membership': 1,
                        'commission_status': 'pending'
                    })])
                    total_amount_without_files += computed_1
                elif computed_1 >= min_rentability:
                    #TODO Revisar: Para este bloque no debería complirse que la rentabilidad sea negativa para aplicar tasas máximas
                    computed_1 = computed_1 * percentage
                    commissions[workday_id]['success']['line_ids'].extend(
                        [
                            (0, 0,
                             {
                                 'amount': computed_1,
                                 'percentage': percent_enterprise_config if partner_id.category_select == 'em' else percentage,
                                 'membership_id': membership.id,
                                 'rfc': membership.trade_rfc,
                                 'dia': rentability,
                                 'partner_id': partner_id.id,
                                 'count_membership': 1,
                                 'tx_month': tx_month,
                                 'total_bills': total_bills,
                                 'commission_status': 'success'
                             })
                        ])
                    line = membership.line_ids.filtered(
                        lambda x: x.file_uploaded_id.id == self.id
                    )
                    reporting.create(
                        {
                            'partner_dm_id':
                                partner_id.dm_id
                                and partner_id.dm_id.id
                                or False,
                            'division': partner_id.position_id.name,
                            'segment': segment,
                            'partner_rm_id': partner_id.id,
                            'membership': membership.number_membership_trade,
                            'trade_name': membership.trade_name,
                            'rfc': membership.trade_rfc,
                            'family': membership.family,
                            'install_date': membership.date_install,
                            'harvest': self._month_in_2_es(
                                calendar.month_name[membership.dia_date.month]
                            ) + " " + str(membership.dia_date.year) or '',
                            'deposit_month': self._month_in_2_es(
                                calendar.month_name[membership.deposit_date.month]
                            ) + " " + str(membership.deposit_date.year) or '',
                            'volume': total_bills,
                            'transaction': tx_month,
                            'rentability': rentability,
                            'percentage': percentage,
                            'commission': computed_1,
                            'file_uploaded_id': self.id,
                        }
                    )
                    total_amount_success += computed_1
                else:
                    #computed_1 = computed_1 * (percent_enterprise_config if partner_id.category_select == 'em' else min_percentage)
                    percentaje_calc = -1
                    if partner_id.category_select == 'em':
                        computed_1 = computed_1 * percent_enterprise_config
                    else:
                        percentaje_calc = rm_max_rate if rentability < 0 and membership.number_membership_trade in maximum_rates_memberships else min_percentage
                        computed_1 = computed_1 * percentaje_calc
                    commissions[workday_id]['success']['line_ids'].extend(
                        [
                            (0, 0,
                             {
                                 'amount': computed_1,
                                 'percentage': percent_enterprise_config if partner_id.category_select == 'em' else percentaje_calc,
                                 'membership_id': membership.id,
                                 'rfc': membership.trade_rfc,
                                 'dia': rentability,
                                 'tx_month': tx_month,
                                 'total_bills': total_bills,
                                 'partner_id': partner_id.id,
                                 'count_membership': 1,
                                 'commission_status': 'failure'
                             })])
                    line = membership.line_ids.filtered(
                        lambda x: x.file_uploaded_id.id == self.id
                    )
                    reporting.create(
                        {
                            'partner_dm_id':
                                partner_id.dm_id
                                and partner_id.dm_id.id
                                or False,
                            'division': partner_id.position_id.name,
                            'segment': segment,
                            'partner_rm_id': partner_id.id,
                            'membership': membership.number_membership_trade,
                            'trade_name': membership.trade_name,
                            'rfc': membership.trade_rfc,
                            'family': membership.family,
                            'install_date': membership.date_install,
                            'harvest': self._month_in_2_es(
                                calendar.month_name[membership.dia_date.month]
                            ) + " " + str(membership.dia_date.year) or  '',
                            'deposit_month': self._month_in_2_es(
                                calendar.month_name[
                                    membership.deposit_date.month
                                ]
                            ) + " " + str(membership.deposit_date.year) or '',
                            'volume': total_bills,
                            'transaction': tx_month,
                            'rentability': rentability,
                            'percentage': percent_enterprise_config
                                if partner_id.category_select == 'em'
                                else min_percentage,
                            'commission': computed_1,
                            'file_uploaded_id': self.id,
                        }
                    )
                    total_amount_failure += computed_1
                if partner_id.dm_id:
                    #La variable percent_calculation_1 tiene el porcentaje que se toma a partir del segmento
                    if (rentability*percent_calculation_1) > min_rentability:
                        percentage_dm = percent_commission_up \
                            if count_membership >= goal_by_month \
                            else percent_commission_down
                    elif 0 <= (rentability*percent_calculation_1) < min_rentability:
                        percentage_dm = dm_percentage_config #habitualmente es 0
                    else:
                        percentage_dm = percent_commission_down

                    dm_rentability = rentability
                    dm_amount = dm_rentability * percentage_dm if \
                        dm_rentability >= min_rentability else 0
                    if self.env['commission.files.status'].is_inactive(
                            membership.number_membership_trade
                    ):
                        if partner_id.dm_id not in pending_dm:
                            pending_dm[partner_id.dm_id] = {
                                'line_ids': [
                                    (0, 0,
                                     {
                                         'partner_id': partner_id.id,
                                         'percentage': percentage_dm,
                                         'count_membership': 1,
                                         'dia': dm_rentability,
                                         'tx_month': tx_month,
                                         'total_bills': total_bills,
                                         'rfc': membership.trade_rfc,
                                         'membership_line': membership.line_ids[
                                             -1].id,
                                         'membership_id': membership.id,
                                         'amount': dm_amount,
                                         'is_success': True if dm_amount > 0 else False,
                                         'commission_status': 'pending'
                                     })
                                ],

                            }
                        else:
                            pending_dm[partner_id.dm_id]['line_ids'].append(
                                (0, 0,
                                 {
                                     'partner_id': partner_id.id,
                                     'percentage': percentage_dm,
                                     'count_membership': 1,
                                     'dia': dm_rentability,
                                     'tx_month': tx_month,
                                     'total_bills': total_bills,
                                     'membership_id': membership.id,
                                     'rfc': membership.trade_rfc,
                                     'membership_line': membership.line_ids[
                                         -1].id,
                                     'amount': dm_amount,
                                     'is_success': True if dm_amount > 0 else False,
                                     'commission_status': 'pending'

                                 })
                            )
                    else:
                        if partner_id.dm_id not in dm:
                            dm[partner_id.dm_id] = {
                                'line_ids': [
                                    (0, 0,
                                     {
                                         'partner_id': partner_id.id,
                                         'percentage': percentage_dm,
                                         'count_membership': 1,
                                         'dia': dm_rentability,
                                         'tx_month': tx_month,
                                         'total_bills': total_bills,
                                         'rfc': membership.trade_rfc,
                                         'membership_id': membership.id,
                                         'amount': dm_amount,
                                         'membership_line': membership.line_ids[
                                             -1].id,
                                         'commission_status': 'success' if
                                         dm_amount > 0
                                         else 'failure'
                                     })
                                ],
                            }
                            #Bloque para DM
                        else:
                            dm[partner_id.dm_id]['line_ids'].append(
                                (0, 0, {
                                    'partner_id': partner_id.id,
                                    'percentage': percentage_dm,
                                    'count_membership': 1,
                                    'dia': dm_rentability,
                                    'tx_month': tx_month,
                                    'total_bills': total_bills,
                                    'membership_id': membership.id,
                                    'rfc': membership.trade_rfc,
                                    'amount': dm_amount,
                                    'membership_line': membership.line_ids[
                                        -1].id,
                                    'commission_status': 'success' if dm_amount > 0
                                    else 'failure'

                                })
                            )
                    if partner_id.dm_id in dm:
                        dm[partner_id.dm_id]['rfc'] = membership.trade_rfc
                    elif partner_id.dm_id in pending_dm:
                        pending_dm[partner_id.dm_id][
                            'rfc'] = membership.trade_rfc
            commissions[workday_id]['success']['count_membership'] = len(
                commissions[workday_id]['success']['line_ids']
            )
            commissions[workday_id]['without_files']['count_membership'] = len(
                commissions[workday_id]['without_files']['line_ids']
            )
            commissions_pending = False
            if commissions[workday_id]['without_files']['count_membership']:
                commissions_pending = commission_partner.create(
                    commissions[workday_id]['without_files']
                )
                if not len(commissions[workday_id]['success']['line_ids']):
                    if partner_id.category_select == 'em':
                        account_ent.create(
                        {
                            'pay_date': membership.deposit_date,
                            'deposit_month':
                                membership.deposit_date and
                                self._month_in_2_es(
                                    calendar.month_name[
                                        membership.deposit_date.month
                                    ]) + " " + str(
                                    membership.deposit_date.year
                                ) or '',
                            'harvest': membership.dia_date and
                                self._month_in_2_es(
                                    calendar.month_name[
                                        membership.dia_date.month
                                        ]) + " " + str(
                                membership.dia_date.year
                            ) or '',
                            'partner_id': partner_id.id,
                            'percentage': percent_enterprise_config,
                            'commission': commissions_pending.amount_commission,
                            'commission_id': commissions_pending.id,
                            'commission_pending_id':
                                commissions_pending and
                                commissions_pending.id or
                                False,
                            'file_uploaded_id': self.id,
                        }
                    )
                    else:
                        account_rm.create(
                            {
                                'deposit_date': membership.deposit_date,
                                'deposit_month':
                                    membership.deposit_date and
                                    self._month_in_2_es(
                                        calendar.month_name[
                                            membership.deposit_date.month
                                        ]) + " " + str(
                                        membership.deposit_date.year
                                    ) or '',
                                'harvest':
                                    membership.dia_date and
                                    self._month_in_2_es(
                                        calendar.month_name[
                                            membership.dia_date.month
                                            ]) + " " + str(
                                        membership.dia_date.year
                                    ) or '',
                                'partner_id': partner_id.id,
                                'percentage': commissions_pending.percentage,
                                'commission_pending_id':
                                    commissions_pending and
                                    commissions_pending.id or
                                    False,
                                'commission_id': commissions_pending.id,
                                'file_uploaded_id': self.id,
                            }
                        )
            if commissions[workday_id]['success']['count_membership']:
                commission_success = commission_partner.create(
                    commissions[workday_id]['success']
                )
                partner_id = commission_success.partner_id
                if partner_id.category_select == 'em':
                    account_ent.create(
                    {
                        'pay_date': membership.deposit_date,
                        'deposit_month':
                            commission_success.date and
                            self._month_in_2_es(
                                calendar.month_name[
                                    membership.deposit_date.month
                                ]) + " " + str(
                                membership.deposit_date.year
                            ) or '',
                        'harvest':
                            commission_success.date and
                            self._month_in_2_es(
                                calendar.month_name[
                                    membership.dia_date.month
                                    ]) + " " + str(
                                membership.dia_date.year) or '',
                        'partner_id': partner_id.id,
                        'percentage': percent_enterprise_config,
                        'commission': commission_success.amount_commission,
                        'commission_id': commission_success.id,
                        'commission_pending_id':
                            commissions_pending and
                            commissions_pending.id or
                            False,
                        'file_uploaded_id': self.id,
                    }
                )
                else:
                    account_rm.create(
                        {
                            'deposit_date': membership.deposit_date,
                            'deposit_month':
                                membership.deposit_date and
                                self._month_in_2_es(
                                    calendar.month_name[
                                        membership.deposit_date.month
                                    ]) + " " + str(
                                    membership.deposit_date.year
                                ) or '',
                            'harvest':
                                membership.dia_date.month and
                                self._month_in_2_es(
                                    calendar.month_name[
                                        membership.dia_date.month
                                        ]) + " " + str(
                                    membership.dia_date.year
                                ) or '',
                            'partner_id': partner_id.id,
                            'partner_dm_id':
                                partner_id.dm_id and partner_id.dm_id.id or False,
                            'division':
                                partner_id.position_id.name,
                            'percentage': commission_success.percentage,
                            'commission': commission_success.amount_commission,
                            'commission_id': commission_success.id,
                            'commission_pending_id':
                                commissions_pending and
                                commissions_pending.id or
                                False,
                            'file_uploaded_id': self.id,
                        }
                    )
        commission_partner.search(
            [
                ('file_uploaded_id', '=', self.id),
                ('category_select', '=', 'dm'),
            ]
        ).unlink()
        #CREAR COMISIONES DE DM
        for key, value in list(dm.items()) + list(pending_dm.items()):
            dm_team = self.env['commission.dm.team'].search(
                [('workday_id', '=', key.workday_id)], limit=1, order='id desc'
            )
            if not dm_team:
                continue
            goal_rm = dm_team.goal_members
            rm_ids = key.rm_ids
            counter_goal = 0
            for rm in rm_ids:
                membership_ids = commission_membership.search([
                    ('workday_id', '=', rm.workday_id),
                ])
                membership_lines_ids = membership_ids.mapped(
                    'line_ids'
                ).filtered(
                    lambda x: x.file_uploaded_id.id == self.id
                )
                if len(membership_lines_ids) >= goal_by_month:
                    counter_goal += 1
            percentage_dm_finaly = percent_commission_up \
                if counter_goal >= goal_rm \
                else percent_commission_down
            total_rm = len(
                list(
                    set(
                        list(
                            map(
                                lambda g: g['partner_id'],
                                list(
                                    map(
                                        lambda t: t[2],
                                        value.get('line_ids', []))
                                ))))))
            for line in value.get('line_ids'):
                #line[2]['percentage'] = line[2]['percentage'] if counter_goal >= goal_rm or line[2]['percentage'] == 0 else percentage_dm_finaly
                line_membership_id=self.env['commission.membership'].browse(line[2]['membership_id'])
                segment_percentage = referred_commission if line_membership_id.segment.upper() == 'REFERIDO' else gptm_commission
                if line[2]['dia'] < 0 and line_membership_id.number_membership_trade in maximum_rates_memberships:
                    line[2]['percentage']=dm_max_rate
                elif line[2]['dia']*segment_percentage>min_rentability:
                    line[2]['percentage']=percentage_dm_finaly
                elif line[2]['dia']*segment_percentage < 0:
                    line[2]['percentage'] = line[2]['percentage']
                elif 0 <= line[2]['dia']*segment_percentage <= min_rentability:
                    line[2]['percentage']=dm_percentage_config
                else:
                    #Nunca debería entrar aquí
                    line[2]['percentage']=-1
            status = 'pending' if all(
                pending == 'pending' for pending in list(map(
                    lambda x: x[2]['commission_status'],
                    value.get('line_ids')
                ))) else 'payed'
            created_dm_commission = commission_partner.create(
                {
                    'total_rm': total_rm,
                    'file_uploaded_id': self.id,
                    'partner_id': key.id,
                    'workday_id': key.workday_id,
                    'date': today,
                    'percentage': percentage_dm_finaly,
                    'state': status,
                    'count_membership': len(value.get('line_ids', [])),
                    'category_select': 'dm',
                    'line_ids': value.get('line_ids', False),
                }
            )
            #Realizando pruebas con esta condición, 
            # si todos los RM de un DM no tienen afiliaciones el primer mes, 
            # no se genera el estado de cuenta del DM
            if status != 'pending' or len(list(dm.items())) == 0:
                account_dm.create(
                    {
                        'date': membership.deposit_date,
                        'deposit_month':
                                membership.deposit_date and
                                self._month_in_2_es(
                                    calendar.month_name[
                                        membership.deposit_date.month
                                    ]) + " " + str(
                                    membership.deposit_date.year
                                ) or '',
                            'harvest':
                                membership.dia_date.month and
                                self._month_in_2_es(
                                    calendar.month_name[
                                        membership.dia_date.month
                                        ]) + " " + str(
                                    membership.dia_date.year
                                ) or '',
                        'partner_id': key.id,
                        'commission_id': created_dm_commission.id,
                        'number_of_rm': total_rm,
                        'percentage': percentage_dm_finaly,
                        'month_goals': goal_rm,
                        'division':
                            key.position_id.name,
                        # 'percentage': commission_success.percentage,
                        'commission': created_dm_commission.amount_commission,
                        'file_uploaded_id': self.id,
                    }
                )
        contextoday = fields.Date.context_today(self)
        files_uploaded = self.search(
            [
                ('date', '>=',
                 datetime.combine(contextoday, time(0, 0, 0))),
                ('date', '<=', datetime.combine(contextoday, time(23, 59, 59))),
                ('file_type', '=', 'status_files')
            ], limit=1, order='date desc'
        )
        if files_uploaded:
            files_uploaded.execute_status_files_file()
        self.check_pendings_commissions(today, self.id)

    @api.model
    def check_pendings_commissions(self, date, file_uploaded_id):
        """
        It checks if there are pending commissions, if there are, it checks if there
        are lines that are no longer pending, if there are, it checks if the
        commission is not pending completely, if it isn't, it creates a new
        commission and writes the lines to it, if it is, it writes the lines to the
        last commission

        :param date: The date of the commission
        :param file_uploaded_id: The id of the file that was uploaded
        """
        inactive_membership = self.env['commission.files.status'].search(
            []).mapped('membership')
        # SIN EXPEDIENTES
        pendings_commissions = self.env[
            'commission.partner.membership'
        ].search(
            [
                ('state', '=', 'pending')
            ]
        )
        # COMISIONES PENDIENTES
        for commission in pendings_commissions:
            # Lines that are no longer pending
            lines = commission.line_ids.filtered(
                lambda x: x.membership_id.number_membership_trade not in
                          inactive_membership
            )
            if lines:
                #En este IF se tratan las líneas de comisiónes que dejan de estar pendientes a falta de expediente
                # If commission is not pending completely.
                if len(lines) == len(commission.line_ids):
                    last_commission = self.env[
                        'commission.partner.membership'
                    ].search(
                        [
                            ('partner_id', '=', commission.partner_id.id),
                            ('state', '=', 'payed')],
                        order='id desc, create_date desc',
                        limit=1
                    )
                    default = {
                        'origin_commission': commission.id,
                        'commission_id': last_commission.id,
                    }
                    new_lines = self.env[
                        'commission.partner.membership.line'
                    ]
                    for line in lines:
                        if not line.membership_file_info in ['without','subsequently']: #Ya no es necesario verificar si tienen origen porque ya todas las líneas dejan de estar pendientes
                            default['commission_status'] = 'success' \
                                if line.is_success \
                                else 'failure'
                            new_lines |= line.copy(default=default)
                            line.membership_file_info='subsequently'
                            self.create_rollback_record(line, False)
                            
                    
                    #commission.active = False
                else:
                    # PARA ESTA COMISION SI HAY LINEAS PENDIENTES:::
                    last_commission = self.env[
                        'commission.partner.membership'
                    ].search(
                        [
                            ('partner_id', '=', commission.partner_id.id),
                            ('state', '=', 'payed')],
                        order='id desc, create_date desc',
                        limit=1
                    )
                    default = {
                        'origin_commission': commission.id,
                        'commission_id': last_commission.id,
                    }
                    new_lines = self.env[
                        'commission.partner.membership.line'
                    ]
                    for line_pending in lines:
                        if not line_pending.membership_file_info in ['without','subsequently']:
                            default['commission_status'] = 'success' \
                                if line_pending.is_success \
                                else 'failure'
                            new_lines |= line_pending.copy(default=default)
                            line_pending.membership_file_info='subsequently'
                            self.create_rollback_record(line_pending, False)

            lines_still_pending = commission.line_ids.filtered(
                lambda x: x.membership_id.number_membership_trade in
                          inactive_membership
            )
            # LINEAS QUE TODAVIA ESTAN PENDIENTES:::
            if lines_still_pending:
                last_commission = self.env['commission.partner.membership'].search([
                            ('partner_id', '=', commission.partner_id.id),
                            ('state', '=', 'pending')],
                            order='id desc, create_date desc',
                            limit=1)
                default = {
                    'origin_commission': commission.id,
                    'commission_id': last_commission.id,
                    }
                new_lines = self.env['commission.partner.membership.line']
                for line_pending in lines_still_pending:
                    if commission.id != last_commission.id and not line_pending.membership_file_info in ['without','subsequently']:
                        default['commission_status'] = 'pending'
                        new_lines = line_pending.copy(default=default)
                        line_pending.membership_file_info='without'
                        self.create_rollback_record(line_pending, False)
                        
        #raise ValidationError('STTOPPP')

    def execute_status_files_file(self, previous_records=False):
        """
        I'm trying to update the status of a membership to inactive if the
        membership number is in the file_status_files field
        """
        self.ensure_one()
        membership = self.env['commission.membership']
        membership_partner_line = self.env[
            'commission.partner.membership.line'
        ]
        self.env['commission.files.status'].search([]).unlink()
        membership = membership.search(
            [
                ('status', '=', 'inactive'), #Sin expediente
                ('state', '!=', 'done') #TODO Revisar en qué momento cambia este estado
            ]
        )
        membership.write(
            {
                'status': 'active',
                'activation_date': fields.Date.today() #TODO Revisar si sería mejor utilizar la fecha (MES DIA) del archivo que se cargó
            }
        )
        values = [
            {
                'membership': file_status.membership,
                'status': file_status.status,
            } for file_status in self.file_status_files
        ]
        files_status_ids = self.env['commission.files.status'].create(values)
        inactive_membership = membership.search(
            [
                (
                    'number_membership_trade',
                    'in',
                    files_status_ids.mapped('membership') or []
                )
            ]
        )
        inactive_membership.write(
            {
                'status': 'inactive',
                'activation_date': False
            }
        )
        if previous_records:
                self.create_rollback_record(False, membership-inactive_membership)
        membership_partner_line.search(
            [
                ('membership_id', 'in', inactive_membership.ids)
            ]
        ).write({'commission_status': 'pending'})

    def execute_employees_file(self):
        """
        It takes all the employees in the system, deactivates them, and then
        re-activates them based on the file that was uploaded
        """
        self.ensure_one()
        all_employees = self.env['res.partner'].search(
            [
                ('is_hsbc_employee', '=', True),
            ]
        )
        all_employees.mapped('user_id').write({'active': False})
        all_employees.mapped('user_ids').write({'active': False})
        all_employees.write({'active': False})
        self.file_employees.execute_employee_file()
        self.file_employees.assign_hierarchy()

    def create_rollback_record(self, commission_line, membership_ids):
        '''Create record in rollback models
        '''
        if commission_line:
            self.env['commission.rollback'].create({'name':commission_line.id})
        if membership_ids:
            for membership in membership_ids:
                self.env['membership.rollback'].create({'name':membership.id})


    def get_memberships_with_maximum_rate(self):
        contextoday = fields.Date.context_today(self)
        file_maximum_rates = self.search(
            [
                ('date', '>=',
                 datetime.combine(contextoday, time(0, 0, 0))),
                ('date', '<=', datetime.combine(contextoday, time(23, 59, 59))),
                ('file_type', '=', 'maximum_rates')
            ], limit=1, order='date desc'
        )
        if file_maximum_rates:
            return file_maximum_rates.file_maximum_rates_files.mapped('name')
