from odoo import fields, models, api


class CommissionRollback(models.Model):
    '''Save the previous state of the records and to be able 
    to return it when a file is deleted
    '''
    _name = 'commission.rollback'
    _description = 'Commission Rollback'

    name = fields.Many2one(
        'commission.partner.membership.line',
        string='Commission Line',
        help='Line requiring return to initial state',
    )
