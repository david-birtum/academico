# Copyright 2017 ForgeFlow S.L.
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl)
from pygments.lexer import _inherit

from odoo import fields, models, api

MONTHS = {
    'january': 'Enero',
    'february': 'Febrero',
    'marzo': 'Marzo',
    'april': 'Abril',
    'may': 'Mayo',
    'june': 'Junio',
    'july': 'Julio',
    'august': 'Agosto',
    'september': 'Septiembre',
    'october': 'Octubre',
    'november': 'Noviembre',
    'december': 'Diciembre'

}


class AbstractCommissionCurrency(models.Model):
    _name = 'commission.currency.abstract'
    _description = 'Abstract Commission Currency'
    _inherit = ['portal.mixin']

    @api.model
    def _get_default_currency(self):
        return self.env.user.company_id.currency_id

    currency_id = fields.Many2one('res.currency', store=True, readonly=True,
                                  string='Currency',
                                  default=_get_default_currency)

    @api.model
    def _month_in_2_es(self, month):
        return MONTHS.get(month.lower(), month)

    def _compute_access_url(self):
        super(AbstractCommissionCurrency, self)._compute_access_url()
        for statement in self:
            statement.access_url = '/my/statements/%s' % (statement.id)

