from odoo import fields, models, api


class MembershipRollback(models.Model):
    '''Save the previous state of membership records and to be able 
    to return it when a file is deleted
    '''
    _name = 'membership.rollback'
    _description = 'Membership Rollback'

    name = fields.Many2one(
        'commission.membership',
        string='Membership',
        help='Membership requiring return to initial state',
    )
